﻿using System;

namespace ChangeCalculator
{
    class Program
    {
        // Constants to hold the maximum allowable amounts for sale and tendered
        const float MAX_SALE_AMOUNT = 1000000;
        const float MAX_TENDERED_AMOUNT = 10000000;

        // Entry point of the program
        static void Main(string[] args)
        {
            // Get the sale amount, tendered amount, and calculate the change
            float amountOfSale = GetSaleAmount();
            float amountOfTendered = GetTenderedAmount(amountOfSale);
            float change = CalculateChange(amountOfSale, amountOfTendered);

            // Display the breakdown of the change
            DisplayChangeBreakdown(change);
        }

        // Method to get the sale amount from user input
        static float GetSaleAmount()
        {
            float amountOfSale;
            while (true)
            {
                Console.Write("Amount of sale: $");
                if (float.TryParse(Console.ReadLine(), out amountOfSale) && amountOfSale > 0 && amountOfSale <= MAX_SALE_AMOUNT)
                    break;  // Exit the loop if valid input is received
                Console.WriteLine($"Enter a valid sale amount between 0 and {MAX_SALE_AMOUNT}.");
            }
            return amountOfSale;
        }

        // Method to get the tendered amount from user input
        static float GetTenderedAmount(float amountOfSale)
        {
            float amountOfTendered;
            do
            {
                Console.Write("Amount of Tendered: $");
                if (float.TryParse(Console.ReadLine(), out amountOfTendered) && amountOfTendered >= amountOfSale && amountOfTendered <= MAX_TENDERED_AMOUNT)
                    break;  // Exit the loop if valid input is received
                Console.WriteLine($"Enter a valid tendered amount (greater than or equal to sale amount and less than {MAX_TENDERED_AMOUNT}).");
            }
            while (true);  // This will keep looping until the break statement is reached
            return amountOfTendered;
        }

        // Method to calculate the change based on sale and tendered amount
        static float CalculateChange(float amountOfSale, float amountOfTendered)
        {
            float change = amountOfTendered - amountOfSale;
            int changeInCents = (int)Math.Round(change * 100);
            int remainder = changeInCents % 5;

            // Determine round direction based on remainder
            int roundDirection = remainder >= 3 ? 1 : 0;

            switch (roundDirection)
            {
                case 1:  // If remainder is greater than or equal to 3, round up
                    changeInCents += (5 - remainder);
                    break;
                case 0:  // Otherwise, round down
                    changeInCents -= remainder;
                    break;
            }

            float roundedChange = changeInCents / 100.0f;
            Console.WriteLine($"Change returned: ${roundedChange:0.00}");
            return roundedChange;
        }


        // Method to display the breakdown of the change amount into various denominations
        static void DisplayChangeBreakdown(float change)
        {
            // Convert the change amount from dollars to cents and round to the nearest cent
            int changeInCents = (int)Math.Round(change * 100, MidpointRounding.AwayFromZero);

            // Calculate the number of twenty dollar bills in the change amount
            int twenties = changeInCents / 2000;
            // Update change amount by subtracting the value of the twenty dollar bills
            changeInCents %= 2000;

            // Calculate the number of ten dollar bills in the change amount
            int tens = changeInCents / 1000;
            // Update change amount by subtracting the value of the ten dollar bills
            changeInCents %= 1000;

            // Calculate the number of five dollar bills in the change amount
            int fives = changeInCents / 500;
            // Update change amount by subtracting the value of the five dollar bills
            changeInCents %= 500;

            // Calculate the number of two dollar coins (toonies) in the change amount
            int toonies = changeInCents / 200;
            // Update change amount by subtracting the value of the two dollar coins
            changeInCents %= 200;

            // Calculate the number of one dollar coins (loonies) in the change amount
            int loonies = changeInCents / 100;
            // Update change amount by subtracting the value of the one dollar coins
            changeInCents %= 100;

            // Calculate the number of quarters in the change amount
            int quarters = changeInCents / 25;
            // Update change amount by subtracting the value of the quarters
            changeInCents %= 25;

            // Calculate the number of dimes in the change amount
            int dimes = changeInCents / 10;
            // Update change amount by subtracting the value of the dimes
            changeInCents %= 10;

            // Calculate the number of nickels in the change amount
            int nickels = changeInCents / 5;
            // Update change amount by subtracting the value of the nickels
            changeInCents %= 5;

            // Display the breakdown of the change amount into various denominations
            Console.WriteLine($"Twenties: {twenties}");
            Console.WriteLine($"Tens: {tens}");
            Console.WriteLine($"Fives: {fives}");
            Console.WriteLine($"Toonies: {toonies}");
            Console.WriteLine($"Loonies: {loonies}");
            Console.WriteLine($"Quarters: {quarters}");
            Console.WriteLine($"Dimes: {dimes}");
            Console.WriteLine($"Nickels: {nickels}");
        }

    }
}
