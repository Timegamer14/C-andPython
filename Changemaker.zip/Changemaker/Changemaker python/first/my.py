'''
Created on Sept 11, 2023
@author: ASUS
'''

# Constants
MAX_SALE_AMOUNT = 1000000  # Maximum allowed sale amount
MAX_TENDERED_AMOUNT = 10000000  # Maximum allowed tendered amount

def get_sale_amount():
    """Prompt the user to enter a sale amount within a valid range."""
    while True:
        try:
            amount_of_sale = float(input(f"Enter sale amount between 0 and {MAX_SALE_AMOUNT}: $"))
            if 0 < amount_of_sale <= MAX_SALE_AMOUNT:
                break
            else:
                print(f"Invalid input! Please enter a sale amount between 0 and {MAX_SALE_AMOUNT}.")
        except ValueError:
            print("Error! Please enter a valid number.")
    return amount_of_sale

def get_tendered_amount(amount_of_sale):
    """Prompt the user to enter a tendered amount within a valid range based on the sale amount."""
    for _ in range(10000):  # Arbitrarily high number to simulate indefinite loop
        try:
            amount_tendered = float(input(f"Enter tendered amount between {amount_of_sale} and {MAX_TENDERED_AMOUNT}: $"))
        except ValueError:
            print("Error! Please enter a valid number.")
            continue  # If an error occurs, it skips the rest of the loop and goes back to the beginning

        # Checking the valid range
        if amount_of_sale <= amount_tendered <= MAX_TENDERED_AMOUNT:
            return amount_tendered  # If the input is valid, it returns the valid amount_tendered value
        else:
            print(f"Invalid input! Please enter a tendered amount greater than or equal to sale amount and less than {MAX_TENDERED_AMOUNT}.")

    print("Too many invalid attempts!")
    return None  # Return None if too many invalid attempts


def calculate_change(amount_of_sale, amount_tendered):
    """Calculate the change amount, rounding to the nearest 5 cents, and print the formatted change."""
    change = amount_tendered - amount_of_sale
    change_in_cents = round(change * 100)
    remainder = change_in_cents % 5

    # Function to handle rounding down
    def round_down():
        return change_in_cents - remainder

    # Function to handle rounding up
    def round_up():
        return change_in_cents + (5 - remainder)

    # Dictionary to act as a switch statement
    switch_rounding = {
        1: round_down,
        2: round_down,
        3: round_up,
        4: round_up,
    }

    # Get the rounding function based on remainder and call it
    change_in_cents = switch_rounding.get(remainder, lambda: change_in_cents)()

    change_rounded_to_five = change_in_cents / 100
    formatted_change = "{:.2f}".format(change_rounded_to_five)
    print(f"Change returned: ${formatted_change}")
    return change_rounded_to_five, change_in_cents  # Return both change and change_in_cents


def display_change_breakdown(change, change_in_cents):
    """Break down the change amount into various denominations and print the result."""
    # change_in_cents calculation is now removed since it's passed as a parameter

    twenties = change_in_cents // 2000
    change_in_cents %= 2000

    tens = change_in_cents // 1000
    change_in_cents %= 1000

    fives = change_in_cents // 500
    change_in_cents %= 500

    toonies = change_in_cents // 200
    change_in_cents %= 200

    loonies = change_in_cents // 100
    change_in_cents %= 100

    quarters = change_in_cents // 25
    change_in_cents %= 25

    dimes = change_in_cents // 10
    change_in_cents %= 10

    nickels = change_in_cents // 5
    change_in_cents %= 5

    # Printing the breakdown of change in various denominations
    print(f"Twenties: {twenties}")
    print(f"Tens: {tens}")
    print(f"Fives: {fives}")
    print(f"Toonies: {toonies}")
    print(f"Loonies: {loonies}")
    print(f"Quarters: {quarters}")
    print(f"Dimes: {dimes}")
    print(f"Nickels: {nickels}")

def main():
    """Main function to orchestrate the execution of other functions in a logical sequence."""
    amount_of_sale = get_sale_amount()
    amount_tendered = get_tendered_amount(amount_of_sale)
    change, change_in_cents = calculate_change(amount_of_sale, amount_tendered)  # Get both change and change_in_cents
    display_change_breakdown(change, change_in_cents)

if __name__ == "__main__":
    main()  # Call main function if script is run directly
