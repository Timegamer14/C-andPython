import os
import sys
import pygame
import random
from pygame import *

pygame.init()
#Screen size
screen_size_display = (width_screen, height_screen) = (600, 150)
#FPS
FPS = 60
#Gravity 
gravity = 0.6
#Colour
black_color = (0,0,0)
white_color = (255,255,255)
bg_color = (235, 235, 235)
#Highest Score
highest_scores = 0
#Screen layout
screen_layout_display = pygame.display.set_mode(screen_size_display)
time_clock = pygame.time.Clock()
#Game display
pygame.display.set_caption("Dino Run ")
#Resourse
jump_sound = pygame.mixer.Sound('resources/jump.wav')
die_sound = pygame.mixer.Sound('resources/die.wav')
checkPoint_sound = pygame.mixer.Sound('resources/checkPoint.wav')

   # Load an image from the resources directory.

   # Parameters:
   # - name: The filename of the image to load.
   # - sx, sy: Optional dimensions to scale the image to.
   # - colorkey: Optional color to be treated as transparent.

   # Returns:
    #A tuple of the loaded image and its rect.
 #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Method                : Load Image
#
# Method parameters    : For easy to load image
#
# Method return        : No 
#
# Synopsis             :

# Modifications        :
#                            Date       Developer       Notes
#                            22/11/23     Dhruvit          
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
def load_image(
    name,
    sx=-1,
    sy=-1,
    colorkey=None,
    ):

 # Construct the full path to the image file.
    fullname = os.path.join('resources', name)
    # Load the image from the specified path.
    img = pygame.image.load(fullname)
    # Convert the image to a pixel format suitable for display.
    img = img.convert()
    # If a colorkey is provided, set the image's colorkey.
    if colorkey is not None:
        if colorkey == -1:
            # If colorkey is -1, get the color of the top-left pixel and use it as the colorkey.
            colorkey = img.get_at((0, 0))
        img.set_colorkey(colorkey, RLEACCEL)

    # If scaling dimensions are provided, scale the image.
    if sx != -1 or sy != -1:
        img = pygame.transform.scale(img, (sx, sy))

    # Return the image and its rect.
    return (img, img.get_rect())
"""
    Load a spritesheet and split it into individual sprites.

    Parameters:
    - s_name: Filename of the sprite sheet.
    - namex, namey: Number of sprites horizontally and vertically.
    - scx, scy: Optional dimensions to scale each sprite to.
    - c_key: Optional color to be treated as transparent.

    Returns:
    A list of sprites and the rect of the first sprite.
    """
def load_sprite_sheet(
        s_name,
        namex,
        namey,
        scx = -1,
        scy = -1,
        c_key = None,
        ):
      
    # Construct the full path to the sprite sheet file.
    fullname = os.path.join('resources', s_name)
    # Load the sprite sheet from the specified path.
    sh = pygame.image.load(fullname)
    # Convert the sprite sheet to a pixel format suitable for display.
    sh = sh.convert()

    # Get the dimensions of the entire sprite sheet.
    sh_rect = sh.get_rect()

    # List to hold all the individual sprites.
    sprites = []

    # Calculate the width and height of each sprite.
    sx = sh_rect.width / namex
    sy = sh_rect.height / namey

    # Extract each sprite from the sprite sheet.
    for i in range(0, namey):
        for j in range(0, namex):
            # Define the rectangle for the current sprite.
            rect = pygame.Rect((j * sx, i * sy, sx, sy))
            # Create a new surface for the sprite.
            img = pygame.Surface(rect.size)
            img = img.convert()
            # Blit the sprite onto the new surface.
            img.blit(sh, (0, 0), rect)

            # If a colorkey is provided, set the sprite's colorkey.
            if c_key is not None:
                if c_key == -1:
                    # If colorkey is -1, get the color of the top-left pixel of the sprite and use it as the colorkey.
                    c_key = img.get_at((0, 0))
                img.set_colorkey(c_key, RLEACCEL)

            # If scaling dimensions are provided, scale the sprite.
            if scx != -1 or scy != -1:
                img = pygame.transform.scale(img, (scx, scy))

            # Add the sprite to the list of sprites.
            sprites.append(img)

    # Get the rect for the first sprite.
    sprite_rect = sprites[0].get_rect()

    # Return the list of sprites and the rect of the first sprite.
    return sprites, sprite_rect

"""
    Display the game over message and the restart button on the screen.
  """
    
    
def gameover_display_message(rbtn_image, gmo_image):
   
     # Get the rect for the restart button image and center it horizontally.
    rbtn_rect = rbtn_image.get_rect()
    rbtn_rect.centerx = width_screen / 2
    # Position the top of the restart button slightly below the midpoint of the screen vertically.
    rbtn_rect.top = height_screen * 0.52

    # Get the rect for the game over message image and center it horizontally and vertically.
    gmo_rect = gmo_image.get_rect()
    gmo_rect.centerx = width_screen / 2
    gmo_rect.centery = height_screen * 0.35

    # Blit both the restart button and game over message onto the screen.
    screen_layout_display.blit(rbtn_image, rbtn_rect)
    screen_layout_display.blit(gmo_image, gmo_rect)
"""
    Extract and return the digits of a number as a list.

    Parameters:
    - num: The number from which to extract digits.

    Returns:
    A list of digits composing the number.
    """
# Define a function 'extractDigits' that takes an integer 'num'.
def extractDigits(num):
    
    # Check if 'num' is a non-negative integer.
    if num > -1:
        # Create an empty list 'd' to store individual digits.
        d = []
        # 'i' is initialized but not used in this function; it's redundant.
        i = 0
        # Use a 'while' loop to extract digits from 'num' until 'num' becomes 0.
        while(num / 10 != 0):
            # Append the last digit of 'num' to the list 'd'.
            d.append(num % 10)
            # Divide 'num' by 10 and convert it to an integer to remove the last digit.
            num = int(num / 10)

        # After the loop, append the remaining digit of 'num' to 'd'.
        d.append(num % 10)
        # If the total digits are less than 5, pad the list 'd' with zeros until it has 5 digits.
        for i in range(len(d),5):
            d.append(0)
        # Reverse the list 'd' to get the digits in the correct order.
        d.reverse()
        # Return the list of digits.
        return d

# Define a Dino class which will represent the dinosaur character in the game.
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Method                : Class Dino
#
# Method parameters    : All the Dino Format (Jump ,run Duck)
#
# Method return        : No 
#
# Synopsis             :

# Modifications        :
#                            Date       Developer       Notes
#                            22/11/23     Dhruvit          
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Dino():
    # Initialize the Dino object with optional size arguments.
    def __init__(self, sx=-1, sy=-1):
        # Load images and rectangles for the dinosaur and ducking sprites.
        self.imgs, self.rect = load_sprite_sheet('dino.png', 5, 1, sx, sy, -1)
        self.imgs1, self.rect1 = load_sprite_sheet('dino_ducking.png', 2, 1, 59, sy, -1)
        # Set the dinosaur's position on the screen.
        self.rect.bottom = int(0.98 * height_screen)
        self.rect.left = width_screen / 15
        # Initialize variables for the current image, score, and state flags.
        self.image = self.imgs[0]
        self.index = 0
        self.counter = 0
        self.score = 0
        self.jumping = False
        self.dead = False
        self.ducking = False
        self.blinking = False
        # Movement is a list containing horizontal and vertical displacement.
        self.movement = [0,0]
        # Jump speed determines how fast the Dino will move upwards when jumping.
        self.jumpSpeed = 11.5

        # Width attributes to manage the different widths when the Dino is standing or ducking.
        self.stand_position_width = self.rect.width
        self.duck_position_width = self.rect1.width

    # Method to draw the Dino on the screen.
    def draw(self):
        screen_layout_display.blit(self.image, self.rect)

    # Method to ensure the Dino does not go below the ground level.
    def checkbounds(self):
        if self.rect.bottom > int(0.98 * height_screen):
            self.rect.bottom = int(0.98 * height_screen)
            self.jumping = False

    # Update method to handle the Dino's animation and position frame by frame.
    def update(self):
        # If jumping, modify the vertical movement by gravity.
        if self.jumping:
            self.movement[1] = self.movement[1] + gravity

        # Animation handling based on the Dino's current state.
        if self.jumping:
            self.index = 0
        elif self.blinking:
            # Blinking animation switch.
            if self.index == 0:
                if self.counter % 400 == 399:
                    self.index = (self.index + 1)%2
            else:
                if self.counter % 20 == 19:
                    self.index = (self.index + 1)%2
        elif self.ducking:
            # Ducking animation switch.
            if self.counter % 5 == 0:
                self.index = (self.index + 1)%2
        else:
            # Running animation switch.
            if self.counter % 5 == 0:
                self.index = (self.index + 1)%2 + 2

        # If dead, show the dead sprite.
        if self.dead:
           self.index = 4

        # Adjust the image and rectangle width based on whether the Dino is ducking.
        if not self.ducking:
            self.image = self.imgs[self.index]
            self.rect.width = self.stand_position_width
        else:
            self.image = self.imgs1[(self.index) % 2]
            self.rect.width = self.duck_position_width

        # Move the Dino's rectangle and ensure it doesn't go out of bounds.
        self.rect = self.rect.move(self.movement)
        self.checkbounds()

        # Increment the score if the Dino is not dead, not blinking, and every 7 frames.
        if not self.dead and self.counter % 7 == 6 and self.blinking == False:
            self.score += 1
            # Play a checkpoint sound every 100 points.
            if self.score % 100 == 0 and self.score != 0:
                if pygame.mixer.get_init() != None:
                    checkPoint_sound.play()

        # Increment the counter for the next frame.
        self.counter = (self.counter + 1)

# Define a Cactus class inheriting from pygame's Sprite class.
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Method                : Class Cactus /Bird/Ground/Cloud
#
# Method parameters    : All class with Sprite and Fuction to opreate
#
# Method return        : yes 
#
# Synopsis             :

# Modifications        :
#                            Date       Developer       Notes
#                            22/11/23     Dhruvit          
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Cactus(pygame.sprite.Sprite):
    # Initialize the Cactus object with speed and optional size arguments.
    def __init__(self, speed=5, sx=-1, sy=-1):
        # Call the parent class (Sprite) constructor and add the cactus to the sprite containers.
        pygame.sprite.Sprite.__init__(self,self.containers)
        # Load the cactus images and set the initial position of the cactus sprite.
        self.imgs, self.rect = load_sprite_sheet('cactus-small.png', 3, 1, sx, sy, -1)
        # Set the cactus's bottom position to slightly above the bottom of the screen.
        self.rect.bottom = int(0.98 * height_screen)
        # Set the initial left position to just off the right side of the screen.
        self.rect.left = width_screen + self.rect.width
        # Randomly select one of the cactus images to display.
        self.image = self.imgs[random.randrange(0, 3)]
        # Set the movement vector, which will move the cactus leftwards at the specified speed.
        self.movement = [-1*speed,0]

    # Method to draw the cactus on the screen at its current position.
    def draw(self):
        screen_layout_display.blit(self.image, self.rect)

    # Update method to handle the cactus's position each frame.
    def update(self):
        # Move the cactus's rectangle by its movement vector.
        self.rect = self.rect.move(self.movement)

        # If the cactus moves past the left side of the screen, remove it from all sprite groups.
        if self.rect.right < 0:
            self.kill()

class birds(pygame.sprite.Sprite):
    def __init__(self, speed=5, sx=-1, sy=-1):
        pygame.sprite.Sprite.__init__(self,self.containers)
        self.imgs, self.rect = load_sprite_sheet('birds.png', 2, 1, sx, sy, -1)
        self.birds_height = [height_screen * 0.82, height_screen * 0.75, height_screen * 0.60]
        self.rect.centery = self.birds_height[random.randrange(0, 3)]
        self.rect.left = width_screen + self.rect.width
        self.image = self.imgs[0]
        self.movement = [-1*speed,0]
        self.index = 0
        self.counter = 0

    def draw(self):
        screen_layout_display.blit(self.image, self.rect)

    def update(self):
        if self.counter % 10 == 0:
            self.index = (self.index+1)%2
        self.image = self.imgs[self.index]
        self.rect = self.rect.move(self.movement)
        self.counter = (self.counter + 1)
        if self.rect.right < 0:
            self.kill()


# Define a Ground class to represent the ground in the game.
class Ground():
    # Initialize the Ground with a default speed.
    def __init__(self, speed=-5):
        # Load two images of the ground and set their rectangles.
        self.image, self.rect = load_image('ground.png', -1, -1, -1)
        self.image1, self.rect1 = load_image('ground.png', -1, -1, -1)
        # Position the bottom of both ground images at the bottom of the screen.
        self.rect.bottom = height_screen
        self.rect1.bottom = height_screen
        # Place the second ground image immediately to the right of the first, creating a continuous loop.
        self.rect1.left = self.rect.right
        # Set the movement speed of the ground.
        self.speed = speed

    # Method to draw both ground images onto the screen.
    def draw(self):
        screen_layout_display.blit(self.image, self.rect)
        screen_layout_display.blit(self.image1, self.rect1)

    # Update method to move the ground to create a scrolling effect.
    def update(self):
        # Move each ground image to the left by the speed amount.
        self.rect.left += self.speed
        self.rect1.left += self.speed

        # If the first ground image has moved completely off the screen, reset its position to the right of the second image.
        if self.rect.right < 0:
            self.rect.left = self.rect1.right

        # If the second ground image has moved completely off the screen, reset its position to the right of the first image.
        if self.rect1.right < 0:
            self.rect1.left = self.rect.right

# Define a Cloud class inheriting from pygame's Sprite class, representing clouds in the background.
class Cloud(pygame.sprite.Sprite):
    # Initialize the Cloud with an x and y position.
    def __init__(self, x, y):
        # Call the parent class (Sprite) constructor and add the cloud to the sprite containers.
        pygame.sprite.Sprite.__init__(self, self.containers)
        # Load the cloud image and set its rectangle.
        self.image, self.rect = load_image('cloud.png', int(90*30/42), 30, -1)
        # Set a slow speed for the cloud's movement to simulate distant clouds moving slower than the ground.
        self.speed = 1
        # Set the initial position of the cloud.
        self.rect.left = x
        self.rect.top = y
        # Set the movement vector for the cloud, moving it horizontally across the screen.
        self.movement = [-1 * self.speed, 0]

    # Method to draw the cloud on the screen at its current position.
    def draw(self):
        screen_layout_display.blit(self.image, self.rect)

    # Update method to handle the cloud's position each frame.
    def update(self):
        # Move the cloud's rectangle by its movement vector.
        self.rect = self.rect.move(self.movement)
        # If the cloud moves past the left side of the screen, remove it from all sprite groups.
        if self.rect.right < 0:
            self.kill()

# Define a Scoreboard class to display the score in the game.
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Method                : Class Scoreboard
#
# Method parameters    :  Fuction to opreate
#
# Method return        : yes 
#
# Synopsis             :

# Modifications        :
#                            Date       Developer       Notes
#                            22/11/23     Dhruvit          
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Scoreboard():
    # Initialize the Scoreboard with optional x and y coordinates.
    def __init__(self, x=-1, y=-1):
        # Start the score at zero.
        self.score = 0
        # Load the sprite sheet for numbers and set up the rectangle for individual numbers.
        self.scre_img, self.screrect = load_sprite_sheet('numbers.png', 12, 1, 11, int(11 * 6 / 5), -1)
        # Create a surface to display the score with a predefined size.
        self.image = pygame.Surface((55, int(11 * 6 / 5)))
        # Get the rectangle of the score display surface.
        self.rect = self.image.get_rect()
        # Set the position of the score display; default is top right of the screen.
        if x == -1:
            self.rect.left = width_screen * 0.89
        else:
            self.rect.left = x
        if y == -1:
            self.rect.top = height_screen * 0.1
        else:
            self.rect.top = y

    # Method to draw the score on the screen.
    def draw(self):
        screen_layout_display.blit(self.image, self.rect)

    # Update the displayed score.
    def update(self, score):
        # Split the score into individual digits.
        score_digits = extractDigits(score)
        # Fill the score display surface with the background color to reset it.
        self.image.fill(bg_color)
        # Blit (draw) each digit of the score onto the score display surface.
        for s in score_digits:
            self.image.blit(self.scre_img[s], self.screrect)
            # Move the rectangle to the right for the next digit.
            self.screrect.left += self.screrect.width
        # Reset the left position of the score rectangle after updating.
        self.screrect.left = 0



# Define a function for the introduction screen of the game.
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Method                : Class introduction_screen
#
# Method parameters    : introduction_screen
#
# Method return        : yes 
#
# Synopsis             :

# Modifications        :
#                            Date       Developer       Notes
#                            22/11/23     Dhruvit          
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
def introduction_screen():
    # Create an instance of Dino, set it to blink at the start.
    ado_dino = Dino(44,47)
    ado_dino.blinking = True
    # Initialize the variable to control the start of the game.
    starting_game = False

    # Load the ground sprite sheet and set its position.
    t_ground, t_ground_rect = load_sprite_sheet('ground.png', 15, 1, -1, -1, -1)
    t_ground_rect.left = width_screen / 20
    t_ground_rect.bottom = height_screen

    # Load the game logo and position it.
    logo, l_rect = load_image('Dino.jpg', 300, 140, -1)
    l_rect.centerx = width_screen * 0.6
    l_rect.centery = height_screen * 0.6

    # Main loop for the introduction screen.
    while not starting_game:
        # Check if the display surface is available.
        if pygame.display.get_surface() == None:
            print("Couldn't load display surface")
            return True  # Indicates an issue occurred.
        else:
            # Handle events like quitting or key presses.
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return True  # Game is exited.
                if event.type == pygame.KEYDOWN:
                    # Start the game if space or up arrow is pressed.
                    if event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                        ado_dino.jumping = True
                        ado_dino.blinking = False
                        ado_dino.movement[1] = -1*ado_dino.jumpSpeed

        # Update the dino sprite.
        ado_dino.update()

        # If the display surface is available, update the intro screen.
        if pygame.display.get_surface() != None:
            screen_layout_display.fill(bg_color)
            screen_layout_display.blit(t_ground[0], t_ground_rect)
            if ado_dino.blinking:
                screen_layout_display.blit(logo, l_rect)  # Show logo only when dino is blinking.
            ado_dino.draw()  # Draw the dino on the screen.

            pygame.display.update()  # Update the display to reflect changes.

        time_clock.tick(FPS)  # Control the frame rate.

        # Check if the game should start.
        if ado_dino.jumping == False and ado_dino.blinking == False:
            starting_game = True  # End intro loop and start the game.
            

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Method                : Class gameplay
#
# Method parameters    : gameplay
#
# Method return        : yes 
#
# Synopsis             :

# Modifications        :
#                            Date       Developer       Notes
#                            22/11/23     Dhruvit          
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
def gameplay():
    global highest_scores
    gp = 4
    s_Menu = False
    g_Over = False
    g_exit = False
    gamer_Dino = Dino(44,47)
    new_grnd = Ground(-1*gp)
    score_boards = Scoreboard()
    highScore = Scoreboard(width_screen * 0.78)
    counter = 0

    cactusan = pygame.sprite.Group()
    smallBird = pygame.sprite.Group()
    skyClouds = pygame.sprite.Group()
    last_end_obs = pygame.sprite.Group()

    Cactus.containers = cactusan
    birds.containers = smallBird
    Cloud.containers = skyClouds

    rbtn_image,rbtn_rect = load_image('replay_button.png',35,31,-1)
    gmo_image,gmo_rect = load_image('game_over.png',190,11,-1)

    t_images,t_rect = load_sprite_sheet('numbers.png',12,1,11,int(11*6/5),-1)
    ado_image = pygame.Surface((22,int(11*6/5)))
    ado_rect = ado_image.get_rect()
    ado_image.fill(bg_color)
    ado_image.blit(t_images[10],t_rect)
    t_rect.left += t_rect.width
    ado_image.blit(t_images[11],t_rect)
    ado_rect.top = height_screen * 0.1
    ado_rect.left = width_screen * 0.73

    while not g_exit:
        while s_Menu:
            pass
        while not g_Over:
            if pygame.display.get_surface() == None:
                print("Couldn't load display surface")
                g_exit = True
                g_Over = True
            else:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        g_exit = True
                        g_Over = True

                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            if gamer_Dino.rect.bottom == int(0.98 * height_screen):
                                gamer_Dino.jumping = True
                                if pygame.mixer.get_init() != None:
                                    jump_sound.play()
                                gamer_Dino.movement[1] = -1*gamer_Dino.jumpSpeed

                        if event.key == pygame.K_DOWN:
                            if not (gamer_Dino.jumping and gamer_Dino.dead):
                                gamer_Dino.ducking = True

                    if event.type == pygame.KEYUP:
                        if event.key == pygame.K_DOWN:
                            gamer_Dino.ducking = False
            for c in cactusan:
                c.movement[0] = -1*gp
                if pygame.sprite.collide_mask(gamer_Dino,c):
                    gamer_Dino.dead = True
                    if pygame.mixer.get_init() != None:
                        die_sound.play()

            for p in smallBird:
                p.movement[0] = -1*gp
                if pygame.sprite.collide_mask(gamer_Dino,p):
                    gamer_Dino.dead = True
                    if pygame.mixer.get_init() != None:
                        die_sound.play()

            if len(cactusan) < 2:
                if len(cactusan) == 0:
                    last_end_obs.empty()
                    last_end_obs.add(Cactus(gp,40,40))
                else:
                    for l in last_end_obs:
                        if l.rect.right < width_screen*0.7 and random.randrange(0, 50) == 10:
                            last_end_obs.empty()
                            last_end_obs.add(Cactus(gp, 40, 40))

            if len(smallBird) == 0 and random.randrange(0,200) == 10 and counter > 500:
                for l in last_end_obs:
                    if l.rect.right < width_screen*0.8:
                        last_end_obs.empty()
                        last_end_obs.add(birds(gp, 46, 40))

            if len(skyClouds) < 5 and random.randrange(0,300) == 10:
                Cloud(width_screen, random.randrange(height_screen / 5, height_screen / 2))

            gamer_Dino.update()
            cactusan.update()
            smallBird.update()
            skyClouds.update()
            new_grnd.update()
            score_boards.update(gamer_Dino.score)
            highScore.update(highest_scores)

            if pygame.display.get_surface() != None:
                screen_layout_display.fill(bg_color)
                new_grnd.draw()
                skyClouds.draw(screen_layout_display)
                score_boards.draw()
                if highest_scores != 0:
                    highScore.draw()
                    screen_layout_display.blit(ado_image, ado_rect)
                cactusan.draw(screen_layout_display)
                smallBird.draw(screen_layout_display)
                gamer_Dino.draw()

                pygame.display.update()
            time_clock.tick(FPS)

            if gamer_Dino.dead:
                g_Over = True
                if gamer_Dino.score > highest_scores:
                    highest_scores = gamer_Dino.score

            if counter%700 == 699:
                new_grnd.speed -= 1
                gp += 1

            counter = (counter + 1)

        if g_exit:
            break

        while g_Over:
            if pygame.display.get_surface() == None:
                print("Couldn't load display surface")
                g_exit = True
                g_Over = False
            else:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        g_exit = True
                        g_Over = False
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            g_exit = True
                            g_Over = False

                        if event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                            g_Over = False
                            gameplay()
            highScore.update(highest_scores)
            if pygame.display.get_surface() != None:
                gameover_display_message(rbtn_image, gmo_image)
                if highest_scores != 0:
                    highScore.draw()
                    screen_layout_display.blit(ado_image, ado_rect)
                pygame.display.update()
            time_clock.tick(FPS)

    pygame.quit()
    quit()

def main():
    isGameQuit = introduction_screen()
    if not isGameQuit:
        gameplay()

main()
