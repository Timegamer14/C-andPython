﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{

    /// <summary>
    /// Represents a cloud in the sky.
    /// </summary>
    public class Cloud : SkyObject
    {
        private const int TEXTURE_COORDS_X = 87;
        private const int TEXTURE_COORDS_Y = 0;

        private const int SPRITE_WIDTH = 46;
        private const int SPRITE_HEIGHT = 17;

        private Sprite _sprite;

        /// <summary>
        /// Gets the speed of the cloud relative to the T-Rex's speed.
        /// </summary>
        public override float Speed => _trex.Speed * 0.5f;

        /// <summary>
        /// Initializes a new instance of the Cloud class.
        /// </summary>
        /// <param name="spriteSheet">The sprite sheet containing cloud textures.</param>
        /// <param name="trex">The T-Rex entity.</param>
        /// <param name="position">The initial position of the cloud.</param>
        public Cloud(Texture2D spriteSheet, Trex trex, Vector2 position) : base(trex, position)
        {
            _sprite = new Sprite(spriteSheet, TEXTURE_COORDS_X, TEXTURE_COORDS_Y, SPRITE_WIDTH, SPRITE_HEIGHT);
        }

        /// <summary>
        /// Draws the cloud using the provided spriteBatch and gameTime.
        /// </summary>
        /// <param name="spriteBatch">The sprite batch used for drawing.</param>
        /// <param name="gameTime">The current game time.</param>
        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            _sprite.Draw(spriteBatch, Position);
        }
    }

}
