﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Collections.ObjectModel;

namespace TrexRunner.Entities
{
    public class EntityManager
    {
        // The list of all game entities currently managed by this EntityManager.
        private readonly List<IGameEntity> _entities = new List<IGameEntity>();

        // Lists to track entities that should be added to or removed from the manager.
        private readonly List<IGameEntity> _entitiesToAdd = new List<IGameEntity>();
        private readonly List<IGameEntity> _entitiesToRemove = new List<IGameEntity>();

        /// <summary>
        /// Gets an enumerable collection of game entities managed by this EntityManager.
        /// </summary>
        public IEnumerable<IGameEntity> Entities => new ReadOnlyCollection<IGameEntity>(_entities);

        /// <summary>
        /// Updates all the game entities managed by this EntityManager.
        /// </summary>
        /// <param name="gameTime">The game time information for the current frame.</param>
        public void Update(GameTime gameTime)
        {
            // Iterate through all entities in the manager.
            foreach (IGameEntity entity in _entities)
            {
                // Skip entities marked for removal.
                if (_entitiesToRemove.Contains(entity))
                    continue;

                // Update the entity.
                entity.Update(gameTime);
            }

            // Add new entities to the manager.
            foreach (IGameEntity entity in _entitiesToAdd)
            {
                _entities.Add(entity);
            }

            // Remove entities marked for removal.
            foreach (IGameEntity entity in _entitiesToRemove)
            {
                _entities.Remove(entity);
            }

            // Clear the lists of entities to add and remove.
            _entitiesToAdd.Clear();
            _entitiesToRemove.Clear();
        }

        /// <summary>
        /// Draws all game entities managed by this EntityManager, sorted by their draw order.
        /// </summary>
        /// <param name="spriteBatch">The SpriteBatch used for drawing.</param>
        /// <param name="gameTime">The game time information for the current frame.</param>
        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            foreach (IGameEntity entity in _entities.OrderBy(e => e.DrawOrder))
            {
                // Draw each entity in the specified draw order.
                entity.Draw(spriteBatch, gameTime);
            }
        }

        /// <summary>
        /// Adds a game entity to the EntityManager for management and updating.
        /// </summary>
        /// <param name="entity">The game entity to be added.</param>
        public void AddEntity(IGameEntity entity)
        {
            if (entity is null)
            {
                throw new ArgumentNullException(nameof(entity), "Null cannot be added as an entity.");
            }

            _entitiesToAdd.Add(entity);
        }

        /// <summary>
        /// Removes a game entity from the EntityManager, preventing it from being updated.
        /// </summary>
        /// <param name="entity">The game entity to be removed.</param>
        public void RemoveEntity(IGameEntity entity)
        {
            if (entity is null)
            {
                throw new ArgumentNullException(nameof(entity), "Null is not a valid entity.");
            }

            _entitiesToRemove.Add(entity);
        }

        /// <summary>
        /// Clears all game entities from the EntityManager.
        /// </summary>
        public void Clear()
        {
            // Mark all existing entities for removal.
            _entitiesToRemove.AddRange(_entities);
        }

        /// <summary>
        /// Retrieves all game entities of a specific type from the EntityManager.
        /// </summary>
        /// <typeparam name="T">The type of game entities to retrieve.</typeparam>
        /// <returns>An enumerable collection of game entities of the specified type.</returns>
        public IEnumerable<T> GetEntitiesOfType<T>() where T : IGameEntity
        {
            // Use LINQ to filter and return game entities of the specified type.
            return _entities.OfType<T>();
        }


    }
}
