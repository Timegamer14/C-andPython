﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{
    public class FlyingDino : Obstacle
    {
        // X and Y coordinates of the sprite on the texture sheet.
        private const int TEXTURE_COORDS_X = 134;
        private const int TEXTURE_COORDS_Y = 0;

        // Width and height of the sprite.
        private const int SPRITE_WIDTH = 46;
        private const int SPRITE_HEIGHT = 42;

        // Length of time each frame of animation is displayed.
        private const float ANIMATION_FRAME_LENGTH = 0.2f;

        // Insets used for collision detection to adjust the hitbox.
        private const int VERTICAL_COLLISION_INSET = 10;
        private const int HORIZONTAL_COLLISION_INSET = 6;

        // Speed of the T-Rex in pixels per second.
        private const float SPEED_PPS = 80f;

        // Sprite animation for the T-Rex.
        private SpriteAnimation _animation;

        // Reference to the Trex entity.
        private Trex _trex;

        // Property to get the collision box of the T-Rex.
        public override Rectangle CollisionBox
        {
            get
            {
                // Calculate the collision box based on the T-Rex's position, sprite dimensions, and insets.
                Rectangle collisionBox = new Rectangle((int)Math.Round(Position.X), (int)Math.Round(Position.Y), SPRITE_WIDTH, SPRITE_HEIGHT);
                collisionBox.Inflate(-HORIZONTAL_COLLISION_INSET, -VERTICAL_COLLISION_INSET);
                return collisionBox;
            }
        }


        public FlyingDino(Trex trex, Vector2 position, Texture2D spriteSheet) : base(trex, position)
        {
            // Create sprites for the animation frames.
            Sprite spriteA = new Sprite(spriteSheet, TEXTURE_COORDS_X, TEXTURE_COORDS_Y, SPRITE_WIDTH, SPRITE_HEIGHT);
            Sprite spriteB = new Sprite(spriteSheet, TEXTURE_COORDS_X + SPRITE_WIDTH, TEXTURE_COORDS_Y, SPRITE_WIDTH, SPRITE_HEIGHT);

            // Initialize class fields.
            _trex = trex;

            // Create and configure the sprite animation.
            _animation = new SpriteAnimation();
            _animation.AddFrame(spriteA, 0);
            _animation.AddFrame(spriteB, ANIMATION_FRAME_LENGTH);
            _animation.AddFrame(spriteA, ANIMATION_FRAME_LENGTH * 2);
            _animation.ShouldLoop = true;
            _animation.Play();
        }

        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            // Draw the current frame of the sprite animation.
            _animation.Draw(spriteBatch, Position);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (_trex.IsAlive)
            {
                // Update the sprite animation and move the FlyingDino horizontally.
                _animation.Update(gameTime);
                Position = new Vector2(Position.X - SPEED_PPS * (float)gameTime.ElapsedGameTime.TotalSeconds, Position.Y);
            }
        }


    }
}
