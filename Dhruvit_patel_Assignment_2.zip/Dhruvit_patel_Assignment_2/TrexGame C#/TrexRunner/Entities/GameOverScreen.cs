﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{
    public class GameOverScreen : IGameEntity
    {
        // X and Y positions of the game over texture within the sprite sheet
        private const int GAME_OVER_TEXTURE_POS_X = 655;
        private const int GAME_OVER_TEXTURE_POS_Y = 14;

        // Width and height of the game over sprite
        public const int GAME_OVER_SPRITE_WIDTH = 192;
        private const int GAME_OVER_SPRITE_HEIGHT = 14;

        // X and Y positions of the button texture within the sprite sheet
        private const int BUTTON_TEXTURE_POS_X = 1;
        private const int BUTTON_TEXTURE_POS_Y = 1;

        // Width and height of the button sprite
        private const int BUTTON_SPRITE_WIDTH = 38;
        private const int BUTTON_SPRITE_HEIGHT = 34;

        // Sprite for the game over text
        private Sprite _textSprite;

        // Sprite for the button
        private Sprite _buttonSprite;

        // Previous keyboard state to track key presses
        private KeyboardState _previousKeyboardState;

        // Reference to the main game instance
        private TRexRunnerGame _game;

        // Draw order for rendering
        public int DrawOrder => 100;

        // Position of the game over screen
        public Vector2 Position { get; set; }

        // Indicates whether the game over screen is enabled
        public bool IsEnabled { get; set; }

        // Calculate the position of the button relative to the game over screen
        private Vector2 ButtonPosition => Position + new Vector2(GAME_OVER_SPRITE_WIDTH / 2 - BUTTON_SPRITE_WIDTH / 2, GAME_OVER_SPRITE_HEIGHT + 20);

        // Calculate the bounding rectangle of the button, taking into account the game's zoom factor
        private Rectangle ButtonBounds
             => new Rectangle(
                 (ButtonPosition * _game.ZoomFactor).ToPoint(),
                 new Point((int)(BUTTON_SPRITE_WIDTH * _game.ZoomFactor), (int)(BUTTON_SPRITE_HEIGHT * _game.ZoomFactor))
                );


        // Initializes a new instance of the GameOverScreen.
        // Takes a sprite sheet and a reference to the TRexRunnerGame.
        public GameOverScreen(Texture2D spriteSheet, TRexRunnerGame game)
        {
            // Create the text sprite for the game over message
            _textSprite = new Sprite(
                spriteSheet,
                GAME_OVER_TEXTURE_POS_X,
                GAME_OVER_TEXTURE_POS_Y,
                GAME_OVER_SPRITE_WIDTH,
                GAME_OVER_SPRITE_HEIGHT
            );

            // Create the button sprite for the restart button
            _buttonSprite = new Sprite(
                spriteSheet,
                BUTTON_TEXTURE_POS_X,
                BUTTON_TEXTURE_POS_Y,
                BUTTON_SPRITE_WIDTH,
                BUTTON_SPRITE_HEIGHT
            );

            // Store a reference to the TRexRunnerGame
            _game = game;
        }

        // Draws the game over screen and restart button, if enabled.
        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            if (!IsEnabled)
                return;

            // Draw the game over text sprite at the specified position
            _textSprite.Draw(spriteBatch, Position);

            // Draw the restart button sprite at the calculated button position
            _buttonSprite.Draw(spriteBatch, ButtonPosition);
        }
        // Updates the game over screen, handling input for restarting the game.
        public void Update(GameTime gameTime)
        {
            // If the game over screen is not enabled, do nothing.
            if (!IsEnabled)
                return;

            // Get the current state of the mouse and keyboard.
            MouseState mouseState = Mouse.GetState();
            KeyboardState keyboardState = Keyboard.GetState();

            // Check if the spacebar or up arrow key is currently pressed.
            bool isKeyPressed = keyboardState.IsKeyDown(Keys.Space) || keyboardState.IsKeyDown(Keys.Up);

            // Check if the spacebar or up arrow key was pressed in the previous frame.
            bool wasKeyPressed = _previousKeyboardState.IsKeyDown(Keys.Space) || _previousKeyboardState.IsKeyDown(Keys.Up);

            // Check if the mouse pointer is over the restart button and the left mouse button is pressed,
            // or if the spacebar or up arrow key was released after being pressed.
            if ((ButtonBounds.Contains(mouseState.Position) && mouseState.LeftButton == ButtonState.Pressed)
                || (wasKeyPressed && !isKeyPressed))
            {
                // Restart the game when the restart button is clicked or the spacebar/up arrow key is released.
                _game.Replay();
            }

            // Store the current keyboard state for the next frame.
            _previousKeyboardState = keyboardState;
        }


    }

}
