﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{

    public class GroundManager : IGameEntity
    {
        private const float GROUND_TILE_POS_Y = 119;  // Y position of the ground tiles.

        private const int SPRITE_WIDTH = 600;          // Width of the ground tile sprite.
        private const int SPRITE_HEIGHT = 14;          // Height of the ground tile sprite.

        private const int SPRITE_POS_X = 2;            // X position of the ground tile sprite in the sprite sheet.
        private const int SPRITE_POS_Y = 54;           // Y position of the ground tile sprite in the sprite sheet.

        private Texture2D _spriteSheet;                // The sprite sheet containing ground tile textures.
        private readonly EntityManager _entityManager; // The entity manager for managing game entities.

        private readonly List<GroundTile> _groundTiles; // List of ground tiles in the game.

        private Sprite _regularSprite;                 // Sprite for regular ground tiles.
        private Sprite _bumpySprite;                   // Sprite for bumpy ground tiles.

        private Trex _trex;                            // The main character of the game (T-Rex).

        private Random _random;                        // Random number generator.

        public int DrawOrder { get; set; }             // Determines the draw order of ground tiles.

      
        public GroundManager(Texture2D spriteSheet, EntityManager entityManager, Trex trex)
        {
            _spriteSheet = spriteSheet;                      // Set the sprite sheet.
            _groundTiles = new List<GroundTile>();           // Initialize the list of ground tiles.
            _entityManager = entityManager;                  // Set the entity manager.

            _regularSprite = new Sprite(spriteSheet,         // Create a sprite for regular ground tiles.
                SPRITE_POS_X, SPRITE_POS_Y, SPRITE_WIDTH, SPRITE_HEIGHT);

            _bumpySprite = new Sprite(spriteSheet,           // Create a sprite for bumpy ground tiles.
                SPRITE_POS_X + SPRITE_WIDTH, SPRITE_POS_Y, SPRITE_WIDTH, SPRITE_HEIGHT);

            _trex = trex;                                    // Set the T-Rex character.
            _random = new Random();                          // Initialize the random number generator.
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {

        }

        /// <summary>
        /// Updates the ground tiles and manages their positions.
        /// </summary>
        
        public void Update(GameTime gameTime)
        {
            if (_groundTiles.Any())
            {
                // Calculate the maximum X position of existing ground tiles.
                float maxPosX = _groundTiles.Max(g => g.PositionX);

                if (maxPosX < 0)
                    SpawnTile(maxPosX); // Spawn a new ground tile if needed.
            }

            List<GroundTile> tilesToRemove = new List<GroundTile>();

            foreach (GroundTile gt in _groundTiles)
            {
                // Update the X position of each ground tile based on T-Rex speed.
                gt.PositionX -= _trex.Speed * (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (gt.PositionX < -SPRITE_WIDTH)
                {
                    // Remove ground tiles that have moved off-screen.
                    _entityManager.RemoveEntity(gt);
                    tilesToRemove.Add(gt);
                }
            }

            foreach (GroundTile gt in tilesToRemove)
                _groundTiles.Remove(gt); // Remove the reference to removed tiles.
        }
        /// <summary>
        /// Initializes the ground manager by clearing existing ground tiles and adding a new regular ground tile.
        /// </summary>
        public void Initialize()
        {
            _groundTiles.Clear();

            // Remove existing ground tiles from the entity manager.
            foreach (GroundTile gt in _entityManager.GetEntitiesOfType<GroundTile>())
            {
                _entityManager.RemoveEntity(gt);
            }

            // Create and add a new regular ground tile.
            GroundTile groundTile = CreateRegularTile(0);
            _groundTiles.Add(groundTile);
            _entityManager.AddEntity(groundTile);
        }

        /// <summary>
        /// Creates a regular ground tile with the specified position.
        /// </summary>
        /// <param name="positionX">The X position of the ground tile.</param>
        /// <returns>The created regular ground tile.</returns>
        private GroundTile CreateRegularTile(float positionX)
        {
            GroundTile groundTile = new GroundTile(positionX, GROUND_TILE_POS_Y, _regularSprite);

            return groundTile;
        }

        /// <summary>
        /// Creates a bumpy ground tile with the specified position.
        /// </summary>
        /// <param name="positionX">The X position of the ground tile.</param>
        /// <returns>The created bumpy ground tile.</returns>
        private GroundTile CreateBumpyTile(float positionX)
        {
            GroundTile groundTile = new GroundTile(positionX, GROUND_TILE_POS_Y, _bumpySprite);

            return groundTile;
        }

        /// <summary>
        /// Spawns a new ground tile after the maximum X position of existing tiles.
        /// </summary>
        /// <param name="maxPosX">The maximum X position of existing ground tiles.</param>
        private void SpawnTile(float maxPosX)
        {
            // Generate a random number between 0 and 1.
            double randomNumber = _random.NextDouble();

            // Calculate the X position for the new ground tile.
            float posX = maxPosX + SPRITE_WIDTH;

            GroundTile groundTile;

            // Decide whether to create a bumpy or regular ground tile based on the random number.
            if (randomNumber > 0.5)
                groundTile = CreateBumpyTile(posX);
            else
                groundTile = CreateRegularTile(posX);

            // Add the new ground tile to the entity manager and the list of ground tiles.
            _entityManager.AddEntity(groundTile);
            _groundTiles.Add(groundTile);
        }


    }
}
