﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{
    public class GroundTile : IGameEntity
    {
        private float _positionY;

        // The X-coordinate of the ground tile's position.
        public float PositionX { get; set; }

        // The sprite representing the ground tile.
        public Sprite Sprite { get; }

        // The draw order determines the layering of this ground tile when rendering.
        public int DrawOrder { get; set; }

        // Constructs a new ground tile with the specified position and sprite.
        public GroundTile(float positionX, float positionY, Sprite sprite)
        {
            PositionX = positionX;
            _positionY = positionY;
            Sprite = sprite;
        }

        // Update method for the ground tile (currently empty).
        public void Update(GameTime gameTime)
        {
        }

        // Draws the ground tile using its sprite at its current position.
        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            Sprite.Draw(spriteBatch, new Vector2(PositionX, _positionY));
        }
    }

}
