﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace TrexRunner.Entities
{
    // Interface representing objects that can be collided with in the game.
    public interface ICollidable
    {
        // Gets the collision box, represented as a rectangle, for the object.
        Rectangle CollisionBox { get; }
    }
}

