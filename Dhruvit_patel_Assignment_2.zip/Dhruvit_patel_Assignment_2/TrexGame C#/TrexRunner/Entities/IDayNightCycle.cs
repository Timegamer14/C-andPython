﻿using Microsoft.Xna.Framework;

namespace TrexRunner.Entities
{
    // Interface representing the day and night cycle in the game.
    public interface IDayNightCycle
    {
        // Gets the count of nights that have passed in the cycle.
        int NightCount { get; }

        // Indicates whether it is currently night in the game cycle.
        bool IsNight { get; }

        // Gets the clear color used for rendering the background during the cycle.
        Color ClearColor { get; }
    }
}
