﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace TrexRunner.Entities
{
    // Interface representing a game entity that can be updated and drawn in the game.
    public interface IGameEntity
    {
        // Gets the draw order of the game entity, determining the rendering order.
        int DrawOrder { get; }

        // Updates the game entity's state based on the provided GameTime.
        void Update(GameTime gameTime);

        // Draws the game entity using the provided SpriteBatch and GameTime.
        void Draw(SpriteBatch spriteBatch, GameTime gameTime);
    }
}
