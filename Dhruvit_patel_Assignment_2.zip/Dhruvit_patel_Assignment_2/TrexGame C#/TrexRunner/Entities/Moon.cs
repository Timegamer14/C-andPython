﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{

    public class Moon : SkyObject
    {
        // Constants for defining the rightmost sprite coordinates of the moon in the sprite sheet.
        private const int RIGHTMOST_SPRITE_COORDS_X = 624;
        private const int RIGHTMOST_SPRITE_COORDS_Y = 2;

        // Constants for defining the width and height of the moon sprite.
        private const int SPRITE_WIDTH = 20;
        private const int SPRITE_HEIGHT = 40;

        // Total number of moon sprites in the animation.
        private const int SPRITE_COUNT = 7;

        // Reference to the day-night cycle for determining whether it's night.
        private readonly IDayNightCycle _dayNightCycle;

        // Sprite object for rendering the moon.
        private Sprite _sprite;

        // Override property to calculate the moon's speed based on the Trex's speed.
        public override float Speed => _trex.Speed * 0.1f;

        // Constructor for creating a Moon object.
        public Moon(IDayNightCycle dayNightCycle, Texture2D spriteSheet, Trex trex, Vector2 position) : base(trex, position)
        {
            _dayNightCycle = dayNightCycle;

            // Create a sprite object for rendering the moon.
            _sprite = new Sprite(spriteSheet, RIGHTMOST_SPRITE_COORDS_X, RIGHTMOST_SPRITE_COORDS_Y, SPRITE_WIDTH, SPRITE_HEIGHT);
        }

        // Override method for drawing the moon.
        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            // Update the moon's sprite.
            UpdateSprite();

            // Check if it's night in the game.
            if (_dayNightCycle.IsNight)
            {
                // Draw the moon sprite at its current position.
                _sprite.Draw(spriteBatch, Position);
            }
        }

        // Method to update the moon's sprite based on the current night count.
        private void UpdateSprite()
        {
            // Calculate the sprite index based on the night count.
            int spriteIndex = _dayNightCycle.NightCount % SPRITE_COUNT;

            // Adjust the sprite width and position for specific sprite indices.
            int spriteWidth = SPRITE_WIDTH;
            int spriteHeight = SPRITE_HEIGHT;

            if (spriteIndex == 3)
            {
                spriteWidth *= 2;
            }

            if (spriteIndex >= 3)
            {
                spriteIndex++;
            }

            // Update the sprite properties with the new dimensions and position.
            _sprite.Height = spriteHeight;
            _sprite.Width = spriteWidth;
            _sprite.X = RIGHTMOST_SPRITE_COORDS_X - spriteIndex * SPRITE_WIDTH;
            _sprite.Y = RIGHTMOST_SPRITE_COORDS_Y;
        }
    }

}
