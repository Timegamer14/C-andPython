﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace TrexRunner.Entities
{
    public abstract class Obstacle : IGameEntity, ICollidable
    {
        private Trex _trex;

        // An abstract property that defines the collision box of the obstacle.
        public abstract Rectangle CollisionBox { get; }

        // The draw order of the obstacle when rendering.
        public int DrawOrder { get; set; }

        // The position of the obstacle in the game world.
        public Vector2 Position { get; protected set; }

        // Constructor for creating an obstacle with a reference to the Trex and an initial position.
        protected Obstacle(Trex trex, Vector2 position)
        {
            _trex = trex;
            Position = position;
        }

        // An abstract method to define how the obstacle is drawn on the screen.
        public abstract void Draw(SpriteBatch spriteBatch, GameTime gameTime);

        // Update method for the obstacle, adjusting its position based on the Trex's speed.
        public virtual void Update(GameTime gameTime)
        {
            // Calculate the new X position of the obstacle based on the Trex's speed and elapsed time.
            float posX = Position.X - _trex.Speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            Position = new Vector2(posX, Position.Y);

            // Check for collisions with the Trex.
            CheckCollisions();
        }

        // Method to check for collisions between the obstacle and the Trex.
        private void CheckCollisions()
        {
            // Get the collision boxes of the obstacle and the Trex.
            Rectangle obstacleCollisionBox = CollisionBox;
            Rectangle trexCollisionBox = _trex.CollisionBox;

            // Check if the obstacle's collision box intersects with the Trex's collision box.
            if (obstacleCollisionBox.Intersects(trexCollisionBox))
            {
                // If there is a collision, the Trex dies.
                _trex.Die();
            }
        }
    }

}
