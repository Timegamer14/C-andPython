﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;

namespace TrexRunner.Entities
{
    public class ObstacleManager : IGameEntity
    {

        private static readonly int[] FLYING_DINO_Y_POSITIONS = new int[] { 90, 62, 24 };

        // Minimum distance for spawning obstacles.
        private const float MIN_SPAWN_DISTANCE = 10;

        // Minimum and maximum obstacle distances.
        private const int MIN_OBSTACLE_DISTANCE = 6;
        private const int MAX_OBSTACLE_DISTANCE = 28;

        // Tolerance for adjusting obstacle distance based on speed.
        private const int OBSTACLE_DISTANCE_SPEED_TOLERANCE = 5;

        // Y positions for large and small cacti obstacles.
        private const int LARGE_CACTUS_POS_Y = 80;
        private const int SMALL_CACTUS_POS_Y = 94;

        // Draw order for obstacles.
        private const int OBSTACLE_DRAW_ORDER = 12;

        // X position at which obstacles are despawned.
        private const int OBSTACLE_DESPAWN_POS_X = -200;

        // Minimum score required to spawn flying dinos.
        private const int FLYING_DINO_SPAWN_SCORE_MIN = 150;

        // Last spawn score and current target distance.
        private double _lastSpawnScore = -1;
        private double _currentTargetDistance;

        // EntityManager, Trex, and ScoreBoard references.
        private readonly EntityManager _entityManager;
        private readonly Trex _trex;
        private readonly ScoreBoard _scoreBoard;

        // Random number generator.
        private readonly Random _random;

        // Texture sheet for obstacles.
        private Texture2D _spriteSheet;

        // Flag to enable/disable obstacle spawning.
        public bool IsEnabled { get; set; }

        // Flag to determine if obstacles can spawn based on score.
        public bool CanSpawnObstacles => IsEnabled && _scoreBoard.Score >= MIN_SPAWN_DISTANCE;

        // Draw order for the ObstacleManager.
        public int DrawOrder => 0;

        public ObstacleManager(EntityManager entityManager, Trex trex, ScoreBoard scoreBoard, Texture2D spriteSheet)
        {
            _entityManager = entityManager;
            _trex = trex;
            _scoreBoard = scoreBoard;
            _random = new Random();
            _spriteSheet = spriteSheet;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {

        }
        public void Update(GameTime gameTime)
        {
            // If obstacle spawning is disabled, return early.
            if (!IsEnabled)
                return;

            // Check if obstacles can spawn and it's time to spawn a new obstacle.
            if (CanSpawnObstacles &&
                (_lastSpawnScore <= 0 || (_scoreBoard.Score - _lastSpawnScore >= _currentTargetDistance)))
            {
                // Calculate the target distance for the next obstacle.
                _currentTargetDistance = _random.NextDouble()
                    * (MAX_OBSTACLE_DISTANCE - MIN_OBSTACLE_DISTANCE) + MIN_OBSTACLE_DISTANCE;

                // Adjust the target distance based on the trex's speed.
                _currentTargetDistance += (_trex.Speed - Trex.START_SPEED) / (Trex.MAX_SPEED - Trex.START_SPEED) * OBSTACLE_DISTANCE_SPEED_TOLERANCE;

                // Update the last spawn score to the current score.
                _lastSpawnScore = _scoreBoard.Score;

                // Spawn a random obstacle.
                SpawnRandomObstacle();
            }

            // Check for obstacles that have moved off-screen and remove them.
            foreach (Obstacle obstacle in _entityManager.GetEntitiesOfType<Obstacle>())
            {
                if (obstacle.Position.X < OBSTACLE_DESPAWN_POS_X)
                    _entityManager.RemoveEntity(obstacle);
            }
        }

        private void SpawnRandomObstacle()
        {
            // TODO: Create an instance of an obstacle and add it to the entity manager.

            Obstacle obstacle = null;

            int cactusGroupSpawnRate = 75;
            int flyingDinoSpawnRate = _scoreBoard.Score >= FLYING_DINO_SPAWN_SCORE_MIN ? 25 : 0;

            int rng = _random.Next(0, cactusGroupSpawnRate + flyingDinoSpawnRate + 1);

            if (rng <= cactusGroupSpawnRate)
            {
                // Randomly determine the group size and whether it's a large or small cactus.
                CactusGroup.GroupSize randomGroupSize = (CactusGroup.GroupSize)_random.Next((int)CactusGroup.GroupSize.Small, (int)CactusGroup.GroupSize.Large + 1);
                bool isLarge = _random.NextDouble() > 0.5f;

                // Determine the vertical position based on whether it's a large or small cactus.
                float posY = isLarge ? LARGE_CACTUS_POS_Y : SMALL_CACTUS_POS_Y;

                // Create a new cactus group obstacle.
                obstacle = new CactusGroup(_spriteSheet, isLarge, randomGroupSize, _trex, new Vector2(TRexRunnerGame.WINDOW_WIDTH, posY));
            }
            else
            {
                // Randomly select a vertical position index for the flying dino.
                int verticalPosIndex = _random.Next(0, FLYING_DINO_Y_POSITIONS.Length);
                float posY = FLYING_DINO_Y_POSITIONS[verticalPosIndex];

                // Create a new flying dino obstacle.
                obstacle = new FlyingDino(_trex, new Vector2(TRexRunnerGame.WINDOW_WIDTH, posY), _spriteSheet);
            }

            // Set the draw order and add the obstacle to the entity manager.
            obstacle.DrawOrder = OBSTACLE_DRAW_ORDER;
            _entityManager.AddEntity(obstacle);
        }

        public void Reset()
        {
            // Remove all obstacles from the entity manager.
            foreach (Obstacle obstacle in _entityManager.GetEntitiesOfType<Obstacle>())
            {
                _entityManager.RemoveEntity(obstacle);
            }

            // Reset the current target distance and last spawn score.
            _currentTargetDistance = 0;
            _lastSpawnScore = -1;
        }

    }
}
