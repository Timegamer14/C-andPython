﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace TrexRunner.Entities
{
    public class ScoreBoard : IGameEntity
    {
        // Constants for the texture coordinates of number digits.
        private const int TEXTURE_COORDS_NUMBER_X = 655;
        private const int TEXTURE_COORDS_NUMBER_Y = 0;
        private const int TEXTURE_COORDS_NUMBER_WIDTH = 10;
        private const int TEXTURE_COORDS_NUMBER_HEIGHT = 13;

        // Number of digits to draw for the score display.
        private const byte NUMBER_DIGITS_TO_DRAW = 5;

        // Constants for the texture coordinates of the "HI" text.
        private const int TEXTURE_COORDS_HI_X = 755;
        private const int TEXTURE_COORDS_HI_Y = 0;
        private const int TEXTURE_COORDS_HI_WIDTH = 20;
        private const int TEXTURE_COORDS_HI_HEIGHT = 13;

        // Margins for positioning the "HI" text and the score.
        private const int HI_TEXT_MARGIN = 28;
        private const int SCORE_MARGIN = 70;

        // Multiplier for incrementing the score during gameplay.
        private const float SCORE_INCREMENT_MULTIPLIER = 0.025f;

        // Constants for flash animation.
        private const float FLASH_ANIMATION_FRAME_LENGTH = 0.333f;
        private const int FLASH_ANIMATION_FLASH_COUNT = 4;

        // Maximum achievable score.
        private const int MAX_SCORE = 99_999;

        // Texture representing the score display.
        private Texture2D _texture;

        // Reference to the Trex character.
        private Trex _trex;

        // Flag indicating whether the flash animation is playing.
        private bool _isPlayingFlashAnimation;

        // Time elapsed during the flash animation.
        private float _flashAnimationTime;

        // Sound effect played when the score increases.
        private SoundEffect _scoreSfx;

        // Current score value.
        private double _score;

        // Property to get and set the score.
        public double Score
        {
            get => _score;
            set => _score = Math.Max(0, Math.Min(value, MAX_SCORE));
        }

        // Property to get the score for display.
        public int DisplayScore => (int)Math.Floor(Score);

        // Property to get and set the high score.
        public int HighScore { get; set; }

        // Property indicating whether a high score is achieved.
        public bool HasHighScore => HighScore > 0;

        // Draw order for rendering the score.
        public int DrawOrder => 100;

        // Position of the score display.
        public Vector2 Position { get; set; }

        public ScoreBoard(Texture2D texture, Vector2 position, Trex trex, SoundEffect scoreSfx)
        {
            _texture = texture;
            _trex = trex;
            Position = position;
            _scoreSfx = scoreSfx;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            // Draw the "HI" text and high score if available.
            if (HasHighScore)
            {
                spriteBatch.Draw(_texture, new Vector2(Position.X - HI_TEXT_MARGIN, Position.Y), new Rectangle(TEXTURE_COORDS_HI_X, TEXTURE_COORDS_HI_Y, TEXTURE_COORDS_HI_WIDTH, TEXTURE_COORDS_HI_HEIGHT), Color.White);

                // Draw the high score.
                DrawScore(spriteBatch, HighScore, Position.X);
            }

            // Only draw the score or flash animation when not in the middle of a flash animation frame.
            if (!_isPlayingFlashAnimation || ((int)(_flashAnimationTime / FLASH_ANIMATION_FRAME_LENGTH) % 2 != 0))
            {
                // Draw the current score or a rounded score when playing the flash animation.
                int score = !_isPlayingFlashAnimation ? DisplayScore : (DisplayScore / 100 * 100);
                DrawScore(spriteBatch, score, Position.X + SCORE_MARGIN);
            }
        }

        private void DrawScore(SpriteBatch spriteBatch, int score, float startPosX)
        {
            // Split the score into individual digits.
            int[] scoreDigits = SplitDigits(score);

            // Initialize the starting position for drawing digits.
            float posX = startPosX;

            // Loop through each digit and draw it.
            foreach (int digit in scoreDigits)
            {
                // Get the texture coordinates for the digit.
                Rectangle textureCoords = GetDigitTextureBounds(digit);

                // Calculate the screen position for drawing the digit.
                Vector2 screenPos = new Vector2(posX, Position.Y);

                // Draw the digit on the screen.
                spriteBatch.Draw(_texture, screenPos, textureCoords, Color.White);

                // Move the drawing position to the right for the next digit.
                posX += TEXTURE_COORDS_NUMBER_WIDTH;
            }
        }

        public void Update(GameTime gameTime)
        {
            // Store the previous displayed score.
            int oldScore = DisplayScore;

            // Increment the score based on the Trex's speed and time elapsed.
            Score += _trex.Speed * SCORE_INCREMENT_MULTIPLIER * gameTime.ElapsedGameTime.TotalSeconds;

            // Check if it's time to play the score increment animation.
            if (!_isPlayingFlashAnimation && (DisplayScore / 100 != oldScore / 100))
            {
                // Start the flash animation.
                _isPlayingFlashAnimation = true;
                _flashAnimationTime = 0;

                // Play the score sound effect.
                _scoreSfx.Play(0.5f, 0, 0);
            }

            // Update the flash animation if it's active.
            if (_isPlayingFlashAnimation)
            {
                _flashAnimationTime += (float)gameTime.ElapsedGameTime.TotalSeconds;

                // Check if the flash animation has completed.
                if (_flashAnimationTime >= FLASH_ANIMATION_FRAME_LENGTH * FLASH_ANIMATION_FLASH_COUNT * 2)
                {
                    // End the flash animation.
                    _isPlayingFlashAnimation = false;
                }
            }
        }

        private int[] SplitDigits(int input)
        {
            // Convert the input integer to a string and pad it to a fixed length with leading zeros.
            string inputStr = input.ToString().PadLeft(NUMBER_DIGITS_TO_DRAW, '0');

            // Create an integer array to store individual digits.
            int[] result = new int[inputStr.Length];

            // Iterate through the characters of the input string and extract numeric values.
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = (int)char.GetNumericValue(inputStr[i]);
            }

            return result;
        }

        private Rectangle GetDigitTextureBounds(int digit)
        {
            // Validate that the digit is within the valid range of 0 to 9.
            if (digit < 0 || digit > 9)
            {
                throw new ArgumentOutOfRangeException("digit", "The value of digit must be between 0 and 9.");
            }

            // Calculate the X and Y coordinates within the texture for the specified digit.
            int posX = TEXTURE_COORDS_NUMBER_X + digit * TEXTURE_COORDS_NUMBER_WIDTH;
            int posY = TEXTURE_COORDS_NUMBER_Y;

            // Create a Rectangle representing the texture coordinates of the digit.
            return new Rectangle(posX, posY, TEXTURE_COORDS_NUMBER_WIDTH, TEXTURE_COORDS_NUMBER_HEIGHT);
        }

    }
}
