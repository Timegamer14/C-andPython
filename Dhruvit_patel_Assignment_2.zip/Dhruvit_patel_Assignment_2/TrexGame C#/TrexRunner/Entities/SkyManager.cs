﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;

namespace TrexRunner.Entities
{
    public class SkyManager : IGameEntity, IDayNightCycle
    {
        /// <summary>
        /// A small value used for comparing floating-point numbers with epsilon precision.
        /// </summary>
        private const float EPSILON = 0.01f;

        /// <summary>
        /// The draw order for cloud objects.
        /// </summary>
        private const int CLOUD_DRAW_ORDER = -1;

        /// <summary>
        /// The draw order for star objects.
        /// </summary>
        private const int STAR_DRAW_ORDER = -3;

        /// <summary>
        /// The draw order for the moon object.
        /// </summary>
        private const int MOON_DRAW_ORDER = -2;

        /// <summary>
        /// The minimum Y position for spawning cloud objects.
        /// </summary>
        private const int CLOUD_MIN_POS_Y = 20;

        /// <summary>
        /// The maximum Y position for spawning cloud objects.
        /// </summary>
        private const int CLOUD_MAX_POS_Y = 70;

        /// <summary>
        /// The minimum Y position for spawning star objects.
        /// </summary>
        private const int STAR_MIN_POS_Y = 10;

        /// <summary>
        /// The maximum Y position for spawning star objects.
        /// </summary>
        private const int STAR_MAX_POS_Y = 60;

        /// <summary>
        /// The minimum distance between cloud spawns.
        /// </summary>
        private const int CLOUD_MIN_DISTANCE = 150;

        /// <summary>
        /// The maximum distance between cloud spawns.
        /// </summary>
        private const int CLOUD_MAX_DISTANCE = 400;

        /// <summary>
        /// The minimum distance between star spawns.
        /// </summary>
        private const int STAR_MIN_DISTANCE = 120;

        /// <summary>
        /// The maximum distance between star spawns.
        /// </summary>
        private const int STAR_MAX_DISTANCE = 380;

        /// <summary>
        /// The Y position for placing the moon.
        /// </summary>
        private const int MOON_POS_Y = 20;

        /// <summary>
        /// The score threshold for transitioning to night-time.
        /// </summary>
        private const int NIGHT_TIME_SCORE = 700;

        /// <summary>
        /// The duration of night-time in terms of score.
        /// </summary>
        private const int NIGHT_TIME_DURATION_SCORE = 250;

        /// <summary>
        /// The duration of day-night transition in seconds.
        /// </summary>
        private const float TRANSITION_DURATION = 2f;

        /// <summary>
        /// The normalized screen color for transitions.
        /// </summary>
        private float _normalizedScreenColor = 1f;

        /// <summary>
        /// The previous score used to track score changes.
        /// </summary>
        private int _previousScore;

        /// <summary>
        /// The score at which night-time starts.
        /// </summary>
        private int _nightTimeStartScore;

        /// <summary>
        /// Indicates whether the game is transitioning to night-time.
        /// </summary>
        private bool _isTransitioningToNight = false;

        /// <summary>
        /// Indicates whether the game is transitioning to day-time.
        /// </summary>
        private bool _isTransitioningToDay = false;

        /// <summary>
        /// The entity manager for managing game entities.
        /// </summary>
        private readonly EntityManager _entityManager;

        /// <summary>
        /// The score board for tracking game scores.
        /// </summary>
        private readonly ScoreBoard _scoreBoard;

        /// <summary>
        /// The T-Rex object in the game.
        /// </summary>
        private readonly Trex _trex;

        /// <summary>
        /// The sprite sheet containing game textures.
        /// </summary>
        private Texture2D _spriteSheet;

        /// <summary>
        /// The inverted sprite sheet used for night-time effects.
        /// </summary>
        private Texture2D _invertedSpriteSheet;

        /// <summary>
        /// The moon object in the game.
        /// </summary>
        private Moon _moon;

        /// <summary>
        /// The overlay texture used for transitions.
        /// </summary>
        private Texture2D _overlay;

        /// <summary>
        /// The target distance between cloud spawns.
        /// </summary>
        private int _targetCloudDistance;

        /// <summary>
        /// The target distance between star spawns.
        /// </summary>
        private int _targetStarDistance;

        /// <summary>
        /// The random number generator for generating random values.
        /// </summary>
        private Random _random;

        /// <summary>
        /// The texture data for the sprite sheet.
        /// </summary>
        private Color[] _textureData;

        /// <summary>
        /// The inverted texture data for the inverted sprite sheet.
        /// </summary>
        private Color[] _invertedTextureData;

        /// <summary>
        /// Gets the clear color used for rendering the screen based on the current screen color during transitions.
        /// </summary>
        public Color ClearColor => new Color(_normalizedScreenColor, _normalizedScreenColor, _normalizedScreenColor);

        /// <summary>
        /// Gets the draw order for rendering sky objects and transitions.
        /// </summary>
        public int DrawOrder => int.MaxValue;

        /// <summary>
        /// Gets the number of night-time periods that have occurred in the game.
        /// </summary>
        public int NightCount { get; private set; }

        /// <summary>
        /// Gets a value indicating whether it is currently night-time in the game.
        /// </summary>
        public bool IsNight => _normalizedScreenColor < 0.5f;

        /// <summary>
        /// Gets the visibility factor of the overlay texture based on the screen color during transitions.
        /// </summary>
        private float OverlayVisibility
        {
            get
            {
                // Calculate the overlay visibility as a function of the screen color.
                return MathHelper.Clamp((0.25f - MathHelper.Distance(0.5f, _normalizedScreenColor)) / 0.25f, 0, 1);
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SkyManager"/> class.
        /// </summary>
        /// <param name="trex">The T-Rex object in the game.</param>
        /// <param name="spriteSheet">The sprite sheet containing game textures.</param>
        /// <param name="invertedSpriteSheet">The inverted sprite sheet used for night-time effects.</param>
        /// <param name="entityManager">The entity manager for managing game entities.</param>
        /// <param name="scoreBoard">The score board for tracking game scores.</param>
        public SkyManager(Trex trex, Texture2D spriteSheet, Texture2D invertedSpriteSheet, EntityManager entityManager, ScoreBoard scoreBoard)
        {
            this._entityManager = entityManager;
            this._scoreBoard = scoreBoard;
            _random = new Random();
            this._trex = trex;
            _spriteSheet = spriteSheet;
            _invertedSpriteSheet = invertedSpriteSheet;

            _textureData = new Color[_spriteSheet.Width * _spriteSheet.Height];
            _invertedTextureData = new Color[_invertedSpriteSheet.Width * _invertedSpriteSheet.Height];

            _spriteSheet.GetData(_textureData);
            _invertedSpriteSheet.GetData(_invertedTextureData);

            // Create an overlay texture with a single gray pixel.
            _overlay = new Texture2D(spriteSheet.GraphicsDevice, 1, 1);
            Color[] overlayData = new[] { Color.Gray };
            _overlay.SetData(overlayData);
        }

        /// <summary>
        /// Draws the overlay texture on the screen during transitions.
        /// </summary>
        /// <param name="spriteBatch">The sprite batch used for rendering.</param>
        /// <param name="gameTime">The game time information.</param>
        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            // Draw the overlay texture on the screen with adjusted visibility.
            if (OverlayVisibility > EPSILON)
                spriteBatch.Draw(_overlay, new Rectangle(0, 0, TRexRunnerGame.WINDOW_WIDTH, TRexRunnerGame.WINDOW_HEIGHT), Color.White * OverlayVisibility);
        }

        /// <summary>
        /// Updates the state of the sky manager and its associated entities.
        /// </summary>
        /// <param name="gameTime">The game time information.</param>
        public void Update(GameTime gameTime)
        {
            // Initialize the moon object if it doesn't exist.
            if (_moon == null)
            {
                _moon = new Moon(this, _spriteSheet, _trex, new Vector2(TRexRunnerGame.WINDOW_WIDTH, MOON_POS_Y));
                _moon.DrawOrder = MOON_DRAW_ORDER;
                _entityManager.AddEntity(_moon);
            }

            // Handle cloud and star spawning based on distance.
            HandleCloudSpawning();
            HandleStarSpawning();

            // Remove sky objects that have moved out of the screen.
            foreach (SkyObject skyObject in _entityManager.GetEntitiesOfType<SkyObject>().Where(s => s.Position.X < -100))
            {
                if (skyObject is Moon moon)
                {
                    // Reposition the moon if it moves out of the screen.
                    moon.Position = new Vector2(TRexRunnerGame.WINDOW_WIDTH, MOON_POS_Y);
                }
                else
                {
                    // Remove other sky objects that are out of the screen.
                    _entityManager.RemoveEntity(skyObject);
                }
            }

            // Check for score changes and trigger transitions.
            if (_previousScore != 0 && _previousScore < _scoreBoard.DisplayScore && _previousScore / NIGHT_TIME_SCORE != _scoreBoard.DisplayScore / NIGHT_TIME_SCORE)
            {
                TransitionToNightTime();
            }

            if (IsNight && (_scoreBoard.DisplayScore - _nightTimeStartScore >= NIGHT_TIME_DURATION_SCORE))
            {
                TransitionToDayTime();
            }

            if (_scoreBoard.DisplayScore < NIGHT_TIME_SCORE && (IsNight || _isTransitioningToNight))
            {
                TransitionToDayTime();
            }

            // Update color transition and store the previous score.
            UpdateTransition(gameTime);
            _previousScore = _scoreBoard.DisplayScore;
        }

        /// <summary>
        /// Updates the transition of the screen color between night and day.
        /// </summary>
        /// <param name="gameTime">The game time information.</param>
        private void UpdateTransition(GameTime gameTime)
        {
            if (_isTransitioningToNight)
            {
                // Decrease the normalized screen color to simulate transition to night.
                _normalizedScreenColor -= (float)gameTime.ElapsedGameTime.TotalSeconds / TRANSITION_DURATION;

                // Ensure that the color does not go below 0.
                if (_normalizedScreenColor < 0)
                    _normalizedScreenColor = 0;

                // Invert textures when screen color is less than 0.5 (night).
                if (_normalizedScreenColor < 0.5f)
                {
                    InvertTextures();
                }
            }
            else if (_isTransitioningToDay)
            {
                // Increase the normalized screen color to simulate transition to day.
                _normalizedScreenColor += (float)gameTime.ElapsedGameTime.TotalSeconds / TRANSITION_DURATION;

                // Ensure that the color does not exceed 1.
                if (_normalizedScreenColor > 1)
                    _normalizedScreenColor = 1;

                // Invert textures when screen color is greater than or equal to 0.5 (day).
                if (_normalizedScreenColor >= 0.5f)
                {
                    InvertTextures();
                }
            }
        }

        /// <summary>
        /// Inverts textures based on whether it's night or day.
        /// </summary>
        private void InvertTextures()
        {
            if (IsNight)
            {
                // Set the sprite sheet data to the inverted texture data for night.
                _spriteSheet.SetData(_invertedTextureData);
            }
            else
            {
                // Set the sprite sheet data to the original texture data for day.
                _spriteSheet.SetData(_textureData);
            }
        }

        /// <summary>
        /// Initiates a transition to night time.
        /// </summary>
        /// <returns>True if the transition was initiated, false otherwise.</returns>
        private bool TransitionToNightTime()
        {
            if (IsNight || _isTransitioningToNight)
                return false;

            // Record the starting score for night time transition.
            _nightTimeStartScore = _scoreBoard.DisplayScore;

            // Set flags to indicate transitioning to night and not to day.
            _isTransitioningToNight = true;
            _isTransitioningToDay = false;

            // Set the normalized screen color to 1 (fully bright).
            _normalizedScreenColor = 1f;

            // Increment the night count.
            NightCount++;

            return true;
        }

        /// <summary>
        /// Initiates a transition to day time.
        /// </summary>
        /// <returns>True if the transition was initiated, false otherwise.</returns>
        private bool TransitionToDayTime()
        {
            if (!IsNight || _isTransitioningToDay)
                return false;

            // Set flags to indicate transitioning to day and not to night.
            _isTransitioningToNight = false;
            _isTransitioningToDay = true;

            // Set the normalized screen color to 0 (fully dark).
            _normalizedScreenColor = 0;

            return true;
        }

        /// <summary>
        /// Handles the spawning of clouds in the sky based on certain conditions.
        /// </summary>
        private void HandleCloudSpawning()
        {
            IEnumerable<Cloud> clouds = _entityManager.GetEntitiesOfType<Cloud>();

            if (clouds.Count() <= 0 || (TRexRunnerGame.WINDOW_WIDTH - clouds.Max(c => c.Position.X)) >= _targetCloudDistance)
            {
                // Randomly determine the distance between cloud spawns.
                _targetCloudDistance = _random.Next(CLOUD_MIN_DISTANCE, CLOUD_MAX_DISTANCE + 1);

                // Randomly determine the vertical position of the new cloud.
                int posY = _random.Next(CLOUD_MIN_POS_Y, CLOUD_MAX_POS_Y + 1);

                // Create a new cloud entity and add it to the entity manager.
                Cloud cloud = new Cloud(_spriteSheet, _trex, new Vector2(TRexRunnerGame.WINDOW_WIDTH, posY));
                cloud.DrawOrder = CLOUD_DRAW_ORDER;

                _entityManager.AddEntity(cloud);
            }
        }

        /// <summary>
        /// Handles the spawning of stars in the night sky based on certain conditions.
        /// </summary>
        private void HandleStarSpawning()
        {
            IEnumerable<Star> stars = _entityManager.GetEntitiesOfType<Star>();

            if (stars.Count() <= 0 || (TRexRunnerGame.WINDOW_WIDTH - stars.Max(c => c.Position.X)) >= _targetStarDistance)
            {
                // Randomly determine the distance between star spawns.
                _targetStarDistance = _random.Next(STAR_MIN_DISTANCE, STAR_MAX_DISTANCE + 1);

                // Randomly determine the vertical position of the new star.
                int posY = _random.Next(STAR_MIN_POS_Y, STAR_MAX_POS_Y + 1);

                // Create a new star entity and add it to the entity manager.
                Star star = new Star(this, _spriteSheet, _trex, new Vector2(TRexRunnerGame.WINDOW_WIDTH, posY));
                star.DrawOrder = STAR_DRAW_ORDER;

                _entityManager.AddEntity(star);
            }
        }


    }
}
