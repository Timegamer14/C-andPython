﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TrexRunner.Entities
{
    /// <summary>
    /// Represents an abstract base class for sky objects in the game.
    /// Sky objects are entities that move across the sky and may be affected by the T-Rex's speed.
    /// </summary>
    public abstract class SkyObject : IGameEntity
    {
        protected readonly Trex _trex;

        /// <summary>
        /// Gets or sets the drawing order of the sky object.
        /// </summary>
        public int DrawOrder { get; set; }

        /// <summary>
        /// Gets the speed of the sky object, which may be influenced by the T-Rex's speed.
        /// </summary>
        public abstract float Speed { get; }

        /// <summary>
        /// Gets or sets the position of the sky object on the screen.
        /// </summary>
        public Vector2 Position { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="SkyObject"/> class.
        /// </summary>
        /// <param name="trex">The T-Rex object.</param>
        /// <param name="position">The initial position of the sky object.</param>
        protected SkyObject(Trex trex, Vector2 position)
        {
            _trex = trex;
            Position = position;
        }

        /// <summary>
        /// Draws the sky object on the screen.
        /// </summary>
        /// <param name="spriteBatch">The sprite batch used for rendering.</param>
        /// <param name="gameTime">The current game time.</param>
        public abstract void Draw(SpriteBatch spriteBatch, GameTime gameTime);

        /// <summary>
        /// Updates the position and behavior of the sky object.
        /// This method is called during the game's update cycle.
        /// </summary>
        /// <param name="gameTime">The current game time.</param>
        public virtual void Update(GameTime gameTime)
        {
            // Update the position of the sky object based on the T-Rex's speed, if the T-Rex is alive.
            if (_trex.IsAlive)
                Position = new Vector2(Position.X - Speed * (float)gameTime.ElapsedGameTime.TotalSeconds, Position.Y);
        }
    }

}
