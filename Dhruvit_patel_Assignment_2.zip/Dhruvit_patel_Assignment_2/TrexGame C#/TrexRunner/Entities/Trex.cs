﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Tracing;
using System.Text;
using TrexRunner.Graphics;

namespace TrexRunner.Entities
{
    public class Trex : IGameEntity, ICollidable
    {

        private const float RUN_ANIMATION_FRAME_LENGTH = 0.1f; // Frame length for running animation

        private const float MIN_JUMP_HEIGHT = 40f; // Minimum jump height

        private const float GRAVITY = 1600f; // Gravity value
        private const float JUMP_START_VELOCITY = -480f; // Initial jump velocity

        private const float CANCEL_JUMP_VELOCITY = -100f; // Velocity to cancel jump

        private const int TREX_IDLE_BACKGROUND_SPRITE_POS_X = 40; // X position of idle background sprite
        private const int TREX_IDLE_BACKGROUND_SPRITE_POS_Y = 0; // Y position of idle background sprite

        public const int TREX_DEFAULT_SPRITE_POS_X = 848; // Default X position of T-Rex sprite
        public const int TREX_DEFAULT_SPRITE_POS_Y = 0; // Default Y position of T-Rex sprite
        public const int TREX_DEFAULT_SPRITE_WIDTH = 44; // Default width of T-Rex sprite
        public const int TREX_DEFAULT_SPRITE_HEIGHT = 52; // Default height of T-Rex sprite

        private const float BLINK_ANIMATION_RANDOM_MIN = 2f; // Minimum time for blink animation
        private const float BLINK_ANIMATION_RANDOM_MAX = 10f; // Maximum time for blink animation
        private const float BLINK_ANIMATION_EYE_CLOSE_TIME = 0.5f; // Duration for eye close during blink animation

        private const int TREX_RUNNING_SPRITE_ONE_POS_X = TREX_DEFAULT_SPRITE_POS_X + TREX_DEFAULT_SPRITE_WIDTH * 2; // X position of running sprite
        private const int TREX_RUNNING_SPRITE_ONE_POS_Y = 0; // Y position of running sprite

        private const int TREX_DUCKING_SPRITE_WIDTH = 59; // Width of ducking sprite

        private const int TREX_DUCKING_SPRITE_ONE_POS_X = TREX_DEFAULT_SPRITE_POS_X + TREX_DEFAULT_SPRITE_WIDTH * 6; // X position of ducking sprite
        private const int TREX_DUCKING_SPRITE_ONE_POS_Y = 0; // Y position of ducking sprite

        private const int TREX_DEAD_SPRITE_POS_X = 1068; // X position of dead sprite
        private const int TREX_DEAD_SPRITE_POS_Y = 0; // Y position of dead sprite

        private const float DROP_VELOCITY = 600f; // Drop velocity

        public const float START_SPEED = 280f; // Starting speed
        public const float MAX_SPEED = 900f; // Maximum speed

        private const float ACCELERATION_PPS_PER_SECOND = 3f; // Acceleration per second

        private const int COLLISION_BOX_INSET = 3; // Collision box inset
        private const int DUCK_COLLISION_REDUCTION = 20; // Ducking collision reduction

        private Sprite _idleBackgroundSprite; // Idle background sprite
        private Sprite _idleSprite; // Idle sprite
        private Sprite _idleBlinkSprite; // Idle blink sprite
        private Sprite _deadSprite; // Dead sprite

        private SoundEffect _jumpSound; // Jump sound effect

        private SpriteAnimation _blinkAnimation; // Blink animation
        private SpriteAnimation _runAnimation; // Run animation
        private SpriteAnimation _duckAnimation; // Duck animation

        private Random _random; // Random number generator

        private float _verticalVelocity; // Vertical velocity
        private float _startPosY; // Starting Y position
        private float _dropVelocity; // Drop velocity

        public event EventHandler JumpComplete; // Event for jump completion
        public event EventHandler Died; // Event for death

        public TrexState State { get; private set; } // Current state of the T-Rex

        public Vector2 Position { get; set; } // Position of the T-Rex

        public bool IsAlive { get; private set; } // Whether the T-Rex is alive

        public float Speed { get; private set; } // Current speed of the T-Rex

        public int DrawOrder { get; set; } // Draw order of the T-Rex

        public Rectangle CollisionBox
        {
            get
            {
                // Create a rectangle representing the collision box of the T-Rex
                Rectangle box = new Rectangle(
                    (int)Math.Round(Position.X), // X-coordinate of the box
                    (int)Math.Round(Position.Y), // Y-coordinate of the box
                    TREX_DEFAULT_SPRITE_WIDTH,   // Width of the box
                    TREX_DEFAULT_SPRITE_HEIGHT   // Height of the box
                );

                // Inflate the collision box to provide a margin for more accurate collisions
                box.Inflate(-COLLISION_BOX_INSET, -COLLISION_BOX_INSET);

                // If the T-Rex is in a ducking state, adjust the collision box
                if (State == TrexState.Ducking)
                {
                    box.Y += DUCK_COLLISION_REDUCTION; // Reduce the Y-coordinate for ducking
                    box.Height -= DUCK_COLLISION_REDUCTION; // Reduce the height for ducking
                }

                return box;
            }
        }


        public Trex(Texture2D spriteSheet, Vector2 position, SoundEffect jumpSound)
        {
            // Initialize the T-Rex's position and sprite for the idle background
            Position = position;
            _idleBackgroundSprite = new Sprite(spriteSheet, TREX_IDLE_BACKGROUND_SPRITE_POS_X, TREX_IDLE_BACKGROUND_SPRITE_POS_Y, TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT);
            State = TrexState.Idle;

            // Store the jump sound effect
            _jumpSound = jumpSound;

            // Initialize the random number generator
            _random = new Random();

            // Initialize the T-Rex's sprites for idle, blinking, running, ducking, and when dead
            _idleSprite = new Sprite(spriteSheet, TREX_DEFAULT_SPRITE_POS_X, TREX_DEFAULT_SPRITE_POS_Y, TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT);
            _idleBlinkSprite = new Sprite(spriteSheet, TREX_DEFAULT_SPRITE_POS_X + TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_POS_Y, TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT);

            // Create and play the blink animation
            _blinkAnimation = new SpriteAnimation();
            CreateBlinkAnimation();
            _blinkAnimation.Play();

            // Store the starting Y position of the T-Rex
            _startPosY = position.Y;

            // Initialize the running animation
            _runAnimation = new SpriteAnimation();
            _runAnimation.AddFrame(new Sprite(spriteSheet, TREX_RUNNING_SPRITE_ONE_POS_X, TREX_RUNNING_SPRITE_ONE_POS_Y, TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT), 0);
            _runAnimation.AddFrame(new Sprite(spriteSheet, TREX_RUNNING_SPRITE_ONE_POS_X + TREX_DEFAULT_SPRITE_WIDTH, TREX_RUNNING_SPRITE_ONE_POS_Y, TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT), RUN_ANIMATION_FRAME_LENGTH);
            _runAnimation.AddFrame(_runAnimation[0].Sprite, RUN_ANIMATION_FRAME_LENGTH * 2);
            _runAnimation.Play();

            // Initialize the ducking animation
            _duckAnimation = new SpriteAnimation();
            _duckAnimation.AddFrame(new Sprite(spriteSheet, TREX_DUCKING_SPRITE_ONE_POS_X, TREX_DUCKING_SPRITE_ONE_POS_Y, TREX_DUCKING_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT), 0);
            _duckAnimation.AddFrame(new Sprite(spriteSheet, TREX_DUCKING_SPRITE_ONE_POS_X + TREX_DUCKING_SPRITE_WIDTH, TREX_DUCKING_SPRITE_ONE_POS_Y, TREX_DUCKING_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT), RUN_ANIMATION_FRAME_LENGTH);
            _duckAnimation.AddFrame(_duckAnimation[0].Sprite, RUN_ANIMATION_FRAME_LENGTH * 2);
            _duckAnimation.Play();

            // Initialize the sprite for when the T-Rex is dead
            _deadSprite = new Sprite(spriteSheet, TREX_DEAD_SPRITE_POS_X, TREX_DEAD_SPRITE_POS_Y, TREX_DEFAULT_SPRITE_WIDTH, TREX_DEFAULT_SPRITE_HEIGHT);

            // Set the T-Rex as alive
            IsAlive = true;
        }

        /// <summary>
        /// Initializes the T-Rex with default settings, such as speed and state, and places it at its starting position.
        /// </summary>
        public void Initialize()
        {
            // Set the T-Rex's speed to the starting speed
            Speed = START_SPEED;

            // Set the T-Rex's state to running
            State = TrexState.Running;

            // Mark the T-Rex as alive
            IsAlive = true;

            // Reset the T-Rex's vertical position to its starting position
            Position = new Vector2(Position.X, _startPosY);
        }


        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            // Check if the T-Rex is alive
            if (IsAlive)
            {
                // Handle different T-Rex states and animations
                if (State == TrexState.Idle)
                {
                    // Draw the idle background and blink animation
                    _idleBackgroundSprite.Draw(spriteBatch, Position);
                    _blinkAnimation.Draw(spriteBatch, Position);
                }
                else if (State == TrexState.Jumping || State == TrexState.Falling)
                {
                    // Draw the idle sprite when jumping or falling
                    _idleSprite.Draw(spriteBatch, Position);
                }
                else if (State == TrexState.Running)
                {
                    // Draw the running animation
                    _runAnimation.Draw(spriteBatch, Position);
                }
                else if (State == TrexState.Ducking)
                {
                    // Draw the ducking animation
                    _duckAnimation.Draw(spriteBatch, Position);
                }
            }
            else
            {
                // If the T-Rex is not alive, draw the dead sprite
                _deadSprite.Draw(spriteBatch, Position);
            }
        }


        public void Update(GameTime gameTime)
        {
            if (State == TrexState.Idle)
            {
                // Handle blinking animation when the T-Rex is idle
                if (!_blinkAnimation.IsPlaying)
                {
                    CreateBlinkAnimation();
                    _blinkAnimation.Play();
                }

                _blinkAnimation.Update(gameTime);
            }
            else if (State == TrexState.Jumping || State == TrexState.Falling)
            {
                // Update T-Rex position during jumping and falling
                Position = new Vector2(Position.X, Position.Y + _verticalVelocity * (float)gameTime.ElapsedGameTime.TotalSeconds + _dropVelocity * (float)gameTime.ElapsedGameTime.TotalSeconds);
                _verticalVelocity += GRAVITY * (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (_verticalVelocity >= 0)
                    State = TrexState.Falling;

                if (Position.Y >= _startPosY)
                {
                    // Reset position and state when landing after a jump
                    Position = new Vector2(Position.X, _startPosY);
                    _verticalVelocity = 0;
                    State = TrexState.Running;

                    OnJumpComplete();
                }
            }
            else if (State == TrexState.Running)
            {
                // Update the running animation
                _runAnimation.Update(gameTime);
            }
            else if (State == TrexState.Ducking)
            {
                // Update the ducking animation
                _duckAnimation.Update(gameTime);
            }

            if (State != TrexState.Idle)
            {
                // Accelerate the T-Rex's speed if not idle
                Speed += ACCELERATION_PPS_PER_SECOND * (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (Speed > MAX_SPEED)
                    Speed = MAX_SPEED;
            }

            _dropVelocity = 0;
        }


        private void CreateBlinkAnimation()
        {
            // Clear existing blink animation frames and set it to not loop
            _blinkAnimation.Clear();
            _blinkAnimation.ShouldLoop = false;

            // Generate a random blink timestamp within the specified range
            double blinkTimeStamp = BLINK_ANIMATION_RANDOM_MIN + _random.NextDouble() * (BLINK_ANIMATION_RANDOM_MAX - BLINK_ANIMATION_RANDOM_MIN);

            // Add frames for blinking animation
            _blinkAnimation.AddFrame(_idleSprite, 0);
            _blinkAnimation.AddFrame(_idleBlinkSprite, (float)blinkTimeStamp);
            _blinkAnimation.AddFrame(_idleSprite, (float)blinkTimeStamp + BLINK_ANIMATION_EYE_CLOSE_TIME);
        }


        public bool BeginJump()
        {
            if (State == TrexState.Jumping || State == TrexState.Falling)
                return false;

            // Play the jump sound effect
            _jumpSound.Play();

            // Set the T-Rex state to jumping
            State = TrexState.Jumping;

            // Initialize vertical velocity for the jump
            _verticalVelocity = JUMP_START_VELOCITY;

            return true;
        }
        /// <summary>
        /// Cancels the T-Rex's jump if conditions are met.
        /// </summary>
        /// <returns>True if the jump is canceled, false otherwise.</returns>
        public bool CancelJump()
        {
            if (State != TrexState.Jumping || (_startPosY - Position.Y) < MIN_JUMP_HEIGHT)
                return false;

            // Reduce vertical velocity to cancel the jump, or set it to zero if already below the cancel threshold
            _verticalVelocity = _verticalVelocity < CANCEL_JUMP_VELOCITY ? CANCEL_JUMP_VELOCITY : 0;

            return true;
        }

        /// <summary>
        /// Puts the T-Rex into a ducking state.
        /// </summary>
        /// <returns>True if the T-Rex successfully ducks, false if already jumping or falling.</returns>
        public bool Duck()
        {
            if (State == TrexState.Jumping || State == TrexState.Falling)
                return false;

            // Set the T-Rex state to ducking
            State = TrexState.Ducking;

            return true;
        }

        /// <summary>
        /// Makes the T-Rex get up from a ducking state to running.
        /// </summary>
        /// <returns>True if the T-Rex successfully gets up, false if not ducking.</returns>
        public bool GetUp()
        {
            if (State != TrexState.Ducking)
                return false;

            // Set the T-Rex state to running
            State = TrexState.Running;

            return true;
        }

        /// <summary>
        /// Initiates a drop action for the T-Rex, causing it to fall faster.
        /// </summary>
        /// <returns>True if the drop is initiated, false if the T-Rex is not jumping or falling.</returns>
        public bool Drop()
        {
            if (State != TrexState.Falling && State != TrexState.Jumping)
                return false;

            // Set the T-Rex state to falling and apply drop velocity
            State = TrexState.Falling;
            _dropVelocity = DROP_VELOCITY;

            return true;
        }

        /// <summary>
        /// Raises the JumpComplete event.
        /// </summary>
        protected virtual void OnJumpComplete()
        {
            EventHandler handler = JumpComplete;
            handler?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Raises the Died event and marks the T-Rex as not alive.
        /// </summary>
        protected virtual void OnDied()
        {
            EventHandler handler = Died;
            handler?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Initiates the T-Rex's death, setting its state to idle and stopping its speed.
        /// </summary>
        /// <returns>True if the T-Rex dies, false if it's already dead.</returns>
        public bool Die()
        {
            if (!IsAlive)
                return false;

            // Set the T-Rex state to idle, stop its speed, and mark it as not alive
            State = TrexState.Idle;
            Speed = 0;
            IsAlive = false;

            // Raise the Died event
            OnDied();

            return true;
        }

    }
}
