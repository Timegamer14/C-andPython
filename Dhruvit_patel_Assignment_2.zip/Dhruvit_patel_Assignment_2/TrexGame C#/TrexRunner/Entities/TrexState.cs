﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TrexRunner.Entities
{
    /// <summary>
    /// Represents the different states of the T-Rex character.
    /// </summary>
    public enum TrexState
    {
        /// <summary>
        /// The T-Rex is in an idle state.
        /// </summary>
        Idle,

        /// <summary>
        /// The T-Rex is running.
        /// </summary>
        Running,

        /// <summary>
        /// The T-Rex is jumping.
        /// </summary>
        Jumping,

        /// <summary>
        /// The T-Rex is ducking.
        /// </summary>
        Ducking,

        /// <summary>
        /// The T-Rex is falling.
        /// </summary>
        Falling
    }
}

