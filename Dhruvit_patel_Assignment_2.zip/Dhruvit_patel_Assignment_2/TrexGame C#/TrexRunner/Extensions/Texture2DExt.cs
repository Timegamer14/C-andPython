﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrexRunner.Extensions
{
    public static class Texture2DExt
    {
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Texture 2D Extensios  
        //
        // Method parameters    : Texture 2D Extensios
        //
        // Method return        : No
        //
        // Synopsis             :  Extensios
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        public static Texture2D InvertColors(this Texture2D texture, Color? excludeColor = null)
        {
            if (texture is null)
                throw new ArgumentNullException(nameof(texture));

            // Create a new Texture2D with the same dimensions.
            Texture2D result = new Texture2D(texture.GraphicsDevice, texture.Width, texture.Height);

            // Get the pixel data from the original texture.
            Color[] pixelData = new Color[texture.Width * texture.Height];
            texture.GetData(pixelData);

            // Invert the colors, excluding the specified color if provided.
            Color[] invertedPixelData = pixelData.Select(p => excludeColor.HasValue && p == excludeColor ? p : new Color(255 - p.R, 255 - p.G, 255 - p.B, p.A)).ToArray();

            // Set the inverted pixel data to the result texture.
            result.SetData(invertedPixelData);

            return result;
        }
    }

}
