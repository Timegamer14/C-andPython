﻿// game states

namespace TrexRunner
{   //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Game State 
    //
    // Method parameters    :GAme State 
    //
    // Method return        : 
    //
    // Synopsis             :  
    //
    // Modifications        :
    //                            Date       Developer       Notes
    //                            22/11/23     Dhruvit          
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    public enum GameState
    {
        Initial,//Initial idle
        Transition,// moving
        Playing,//Running
        GameOver//stop
    }
}
