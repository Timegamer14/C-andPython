﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace TrexRunner.Graphics
{
    public class Sprite
    {
        public Texture2D Texture { get; set; }    // The texture of the sprite
        public int X { get; set; }                // X-coordinate position of the sprite within the texture
        public int Y { get; set; }                // Y-coordinate position of the sprite within the texture
        public int Width { get; set; }            // Width of the sprite
        public int Height { get; set; }           // Height of the sprite
        public Color TintColor { get; set; } = Color.White; // Tint color applied to the sprite
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Sprite  
        //
        // Method parameters    :Sprite
        //
        // Method return        : No
        //
        // Synopsis             :  Graohics
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        public Sprite(Texture2D texture, int x, int y, int width, int height)
        {
            Texture = texture;
            X = x;
            Y = y;
            Width = width;
            Height = height;
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 position)
        {
            // Draw the sprite at the specified position
            spriteBatch.Draw(Texture, position, new Rectangle(X, Y, Width, Height), TintColor);
        }
    }

}
