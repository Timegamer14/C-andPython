﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Xna.Framework.Graphics;
using SharpDX.Direct3D9;

namespace TrexRunner.Graphics
{
    public class SpriteAnimation
    {
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Sprite Animantion 
        //
        // Method parameters    :Sprite Animation
        //
        // Method return        : No
        //
        // Synopsis             :  Graohics
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

        private List<SpriteAnimationFrame> _frames = new List<SpriteAnimationFrame>();

        // Gets a frame at the specified index.
        public SpriteAnimationFrame this[int index]
        {
            get
            {
                return GetFrame(index);
            }
        }

        // Gets the total number of frames in the animation.
        public int FrameCount => _frames.Count;

        // Gets the current frame based on playback progress.
        public SpriteAnimationFrame CurrentFrame
        {
            get
            {
                return _frames
                    .Where(f => f.TimeStamp <= PlaybackProgress)
                    .OrderBy(f => f.TimeStamp)
                    .LastOrDefault();
            }
        }

        // Gets the total duration of the animation.
        public float Duration
        {
            get
            {
                if (!_frames.Any())
                    return 0;

                return _frames.Max(f => f.TimeStamp);
            }
        }

        // Indicates whether the animation is currently playing.
        public bool IsPlaying { get; private set; }

        // Gets the current progress of animation playback.
        public float PlaybackProgress { get; private set; }

        // Indicates whether the animation should loop when it reaches the end.
        public bool ShouldLoop { get; set; } = true;

        // Adds a frame to the animation with a specified sprite and timestamp.
        public void AddFrame(Sprite sprite, float timeStamp)
        {
            SpriteAnimationFrame frame = new SpriteAnimationFrame(sprite, timeStamp);
            _frames.Add(frame);
        }

        // Updates the animation's playback progress based on elapsed game time.
        public void Update(GameTime gameTime)
        {
            if (IsPlaying)
            {
                PlaybackProgress += (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (PlaybackProgress > Duration)
                {
                    if (ShouldLoop)
                        PlaybackProgress -= Duration;
                    else
                        Stop();
                }
            }
        }

        // Draws the current frame of the animation at the specified position.
        public void Draw(SpriteBatch spriteBatch, Vector2 position)
        {
            SpriteAnimationFrame frame = CurrentFrame;

            if (frame != null)
                frame.Sprite.Draw(spriteBatch, position);
        }

        // Starts playing the animation.
        public void Play()
        {
            IsPlaying = true;
        }

        // Stops the animation and resets the playback progress.
        public void Stop()
        {
            IsPlaying = false;
            PlaybackProgress = 0;
        }

        // Gets a frame at the specified index.
        public SpriteAnimationFrame GetFrame(int index)
        {
            if (index < 0 || index >= _frames.Count)
                throw new ArgumentOutOfRangeException(nameof(index), "A frame with index " + index + " does not exist in this animation.");

            return _frames[index];
        }

        // Clears all frames from the animation and stops playback.
        public void Clear()
        {
            Stop();
            _frames.Clear();
        }

        // Creates a simple animation with consecutive frames from a sprite sheet.
        public static SpriteAnimation CreateSimpleAnimation(Texture2D texture, Point startPos, int width, int height, Point offset, int frameCount, float frameLength)
        {
            if (texture == null)
                throw new ArgumentNullException(nameof(texture));

            SpriteAnimation anim = new SpriteAnimation();

            for (int i = 0; i < frameCount; i++)
            {
                Sprite sprite = new Sprite(texture, startPos.X + i * offset.X, startPos.Y + i * offset.Y, width, height);
                anim.AddFrame(sprite, frameLength * i);

                if (i == frameCount - 1)
                    anim.AddFrame(sprite, frameLength * (i + 1));
            }

            return anim;
        }
    }

}
