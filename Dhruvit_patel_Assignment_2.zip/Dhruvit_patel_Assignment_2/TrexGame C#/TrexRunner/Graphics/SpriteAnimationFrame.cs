﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrexRunner.Graphics
{
    public class SpriteAnimationFrame
    {
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Sprite   Frame
        //
        // Method parameters    :Sprite Frame
        //
        // Method return        : No
        //
        // Synopsis             :  Graohics
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

        private Sprite _sprite;

        // Gets or sets the sprite for this animation frame.
        public Sprite Sprite
        {
            get
            {
                return _sprite;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException(nameof(value), "The sprite cannot be null.");

                _sprite = value;
            }
        }

        // Gets the timestamp of this animation frame.
        public float TimeStamp { get; }

        // Initializes a new instance of the SpriteAnimationFrame class with the specified sprite and timestamp.
        public SpriteAnimationFrame(Sprite sprite, float timeStamp)
        {
            Sprite = sprite;
            TimeStamp = timeStamp;
        }
    }

}
