﻿using System;
// start method to run game
namespace TrexRunner
{
    public static class Program
    {
        [STAThread]
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Run  
        //
        // Method parameters    :Run  
        //
        // Method return        : 
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        static void Main()//main
        {
            using (var game = new TRexRunnerGame())// Game run from Here
                game.Run();
        }
    }
}
