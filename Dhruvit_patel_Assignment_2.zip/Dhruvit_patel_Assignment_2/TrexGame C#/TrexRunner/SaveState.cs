﻿using System;
using System.Collections.Generic;
using System.Text;
// Save method for highscore and score with date
namespace TrexRunner
{
    [Serializable]
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Save State 
    //
    // Method parameters    :Save State 
    //
    // Method return        : 
    //
    // Synopsis             :  
    //
    // Modifications        :
    //                            Date       Developer       Notes
    //                            22/11/23     Dhruvit          
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    public class SaveState
    {
        public int Highscore { get; set; } //High score
        public DateTime HighscoreDate { get; set; } // Date & time highscore
    }
}
