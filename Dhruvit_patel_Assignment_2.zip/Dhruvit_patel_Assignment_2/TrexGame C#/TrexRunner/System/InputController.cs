﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using TrexRunner.Entities;

namespace TrexRunner.System
{

    public class InputController
    {
        private bool _isBlocked;                 // Flag to block input temporarily
        private Trex _trex;                      // Reference to the Trex character
        private KeyboardState _previousKeyboardState; // Stores the previous keyboard state for input comparison

        public InputController(Trex trex)
        {
            _trex = trex;
        }
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : ProcessControls 
        //
        // Method parameters    :ProcessControls
        //
        // Method return        : No
        //
        // Synopsis             :  Bool
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        public void ProcessControls(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            if (!_isBlocked)
            {
                bool isJumpKeyPressed = keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.Space);
                bool wasJumpKeyPressed = _previousKeyboardState.IsKeyDown(Keys.Up) || _previousKeyboardState.IsKeyDown(Keys.Space);

                if (!wasJumpKeyPressed && isJumpKeyPressed)
                {
                    // Trigger a jump if not already jumping
                    if (_trex.State != TrexState.Jumping)
                        _trex.BeginJump();
                }
                else if (_trex.State == TrexState.Jumping && !isJumpKeyPressed)
                {
                    // Cancel jump if jump key is released during a jump
                    _trex.CancelJump();
                }
                else if (keyboardState.IsKeyDown(Keys.Down))
                {
                    if (_trex.State == TrexState.Jumping || _trex.State == TrexState.Falling)
                        _trex.Drop(); // Drop if jumping or falling
                    else
                        _trex.Duck(); // Duck if not jumping or falling
                }
                else if (_trex.State == TrexState.Ducking && !keyboardState.IsKeyDown(Keys.Down))
                {
                    // Get up from ducking if the down key is released
                    _trex.GetUp();
                }
            }

            _previousKeyboardState = keyboardState;

            _isBlocked = false;
        }

        public void BlockInputTemporarily()
        {
            _isBlocked = true; // Block input temporarily
        }
    }

}
