﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Diagnostics;
using TrexRunner.Entities;
using TrexRunner.Graphics;
using TrexRunner.System;
using TrexRunner.Extensions;
using SharpDX.MediaFoundation;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TrexRunner
{

    public class TRexRunnerGame : Game
    {
        //Disply Deafult and zoom

        public enum DisplayMode
        {
            Default,
            Zoomed
        }
        // Title Text
        public const string GAME_TITLE = "Dino Runner";

        // Asset names
        private const string ASSET_NAME_SPRITESHEET = "TrexSpritesheet";  // Sprite sheet
        private const string ASSET_NAME_SFX_HIT = "hit";                 // Hit sound effect
        private const string ASSET_NAME_SFX_SCORE_REACHED = "score-reached";
        private const string ASSET_NAME_SFX_BUTTON_PRESS = "button-press"; // Button pressed sound effect (spacebar and up arrow key)

        // Window dimensions
        public const int WINDOW_WIDTH = 600;   // Window width
        public const int WINDOW_HEIGHT = 150;  // Window height

        // Trex starting position
        public const int TREX_START_POS_Y = WINDOW_HEIGHT - 16; // Initial Y position of the Trex
        public const int TREX_START_POS_X = 1;                  // Initial X position of the Trex

        // Score board position
        private const int SCORE_BOARD_POS_X = WINDOW_WIDTH - 130; // Score board X position
        private const int SCORE_BOARD_POS_Y = 10;                // Score board Y position

        // Animation speed
        private const float FADE_IN_ANIMATION_SPEED = 820f;       // Speed of fade-in animation

        // Save file name
        private const string SAVE_FILE_NAME = "Save.dat";          // Name of the save file

        // Display zoom factor
        public const int DISPLAY_ZOOM_FACTOR = 2;                 // Zoom factor for display

        // Graphics and rendering variables
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        // Sound effects
        private SoundEffect _sfxHit;
        private SoundEffect _sfxButtonPress;
        private SoundEffect _sfxScoreReached;

        // Textures and sprites
        private Texture2D _spriteSheetTexture;
        private Texture2D _fadeInTexture;
        private Texture2D _invertedSpriteSheet;

        // Fade-in texture position
        private float _fadeInTexturePosX;

        // Game entities and components
        private Trex _trex;
        private ScoreBoard _scoreBoard;
        private InputController _inputController;
        private GroundManager _groundManager;
        private ObstacleManager _obstacleManager;
        private SkyManager _skyManager;
        private GameOverScreen _gameOverScreen;
        private EntityManager _entityManager;

        // Input handling
        private KeyboardState _previousKeyboardState;

        // Highscore date
        private DateTime _highscoreDate;

        // Transformation matrix for rendering
        private Matrix _transformMatrix = Matrix.Identity;

        // Current game state
        public GameState State { get; private set; }

        // Display mode for the window
        public DisplayMode WindowDisplayMode { get; set; } = DisplayMode.Default;

        // Zoom factor for display
        public float ZoomFactor => WindowDisplayMode == DisplayMode.Default ? 1 : DISPLAY_ZOOM_FACTOR;


        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : TRexRunnerGame 
        //
        // Method parameters    : TRexRunnerGame
        //
        // Method return        : no
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

        public TRexRunnerGame()
        {
            // Initialize the game
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            _entityManager = new EntityManager();

            // Set the initial game state and fade-in texture position
            State = GameState.Initial;
            _fadeInTexturePosX = Trex.TREX_DEFAULT_SPRITE_WIDTH;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here (if needed)

            base.Initialize();

            // Set the game window title
            Window.Title = GAME_TITLE;

            // Configure graphics settings
            _graphics.PreferredBackBufferHeight = WINDOW_HEIGHT;
            _graphics.PreferredBackBufferWidth = WINDOW_WIDTH;
            _graphics.SynchronizeWithVerticalRetrace = true;
            _graphics.ApplyChanges();
        }

        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : LoadContent 
        //
        // Method parameters    : LoadContent & save Data
        //
        // Method return        : 
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        protected override void LoadContent()
        {
            // Create a SpriteBatch for rendering
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load sound effects
            _sfxButtonPress = Content.Load<SoundEffect>(ASSET_NAME_SFX_BUTTON_PRESS);
            _sfxHit = Content.Load<SoundEffect>(ASSET_NAME_SFX_HIT);
            _sfxScoreReached = Content.Load<SoundEffect>(ASSET_NAME_SFX_SCORE_REACHED);

            // Load the main sprite sheet
            _spriteSheetTexture = Content.Load<Texture2D>(ASSET_NAME_SPRITESHEET);

            // Invert the sprite sheet colors to create an alternate version
            _invertedSpriteSheet = _spriteSheetTexture.InvertColors(Color.Transparent);

            // Create a 1x1 white texture for fading in
            _fadeInTexture = new Texture2D(GraphicsDevice, 1, 1);
            _fadeInTexture.SetData(new Color[] { Color.White });

            // Initialize the T-Rex character
            _trex = new Trex(_spriteSheetTexture, new Vector2(TREX_START_POS_X, TREX_START_POS_Y - Trex.TREX_DEFAULT_SPRITE_HEIGHT), _sfxButtonPress);
            _trex.DrawOrder = 100;
            _trex.JumpComplete += trex_JumpComplete;
            _trex.Died += trex_Died;

            // Create and initialize the score board
            _scoreBoard = new ScoreBoard(_spriteSheetTexture, new Vector2(SCORE_BOARD_POS_X, SCORE_BOARD_POS_Y), _trex, _sfxScoreReached);

            // Create the input controller for handling user input
            _inputController = new InputController(_trex);

            // Create and initialize game components
            _groundManager = new GroundManager(_spriteSheetTexture, _entityManager, _trex);
            _obstacleManager = new ObstacleManager(_entityManager, _trex, _scoreBoard, _spriteSheetTexture);
            _skyManager = new SkyManager(_trex, _spriteSheetTexture, _invertedSpriteSheet, _entityManager, _scoreBoard);

            // Create the game over screen
            _gameOverScreen = new GameOverScreen(_spriteSheetTexture, this);
            _gameOverScreen.Position = new Vector2(WINDOW_WIDTH / 2 - GameOverScreen.GAME_OVER_SPRITE_WIDTH / 2, WINDOW_HEIGHT / 2 - 30);

            // Add game entities to the entity manager
            _entityManager.AddEntity(_trex);
            _entityManager.AddEntity(_groundManager);
            _entityManager.AddEntity(_scoreBoard);
            _entityManager.AddEntity(_obstacleManager);
            _entityManager.AddEntity(_gameOverScreen);
            _entityManager.AddEntity(_skyManager);

            // Initialize the ground manager
            _groundManager.Initialize();

            // Load saved game state
            LoadSaveState();
        }
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : trex_Died /trex_JumpComplete
        //
        // Method parameters    : trex_Died & trex_JumpComplete
        //
        // Method return        : 
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        private void trex_Died(object sender, EventArgs e)
        {
            // Set game state to "Game Over"
            State = GameState.GameOver;

            // Disable obstacle manager and enable game over screen
            _obstacleManager.IsEnabled = false;
            _gameOverScreen.IsEnabled = true;

            // Play the "hit" sound effect
            _sfxHit.Play();

            // Output debug information
            Debug.WriteLine("Game Over: " + DateTime.Now);

            // Check for a new high score
            if (_scoreBoard.DisplayScore > _scoreBoard.HighScore)
            {
                Debug.WriteLine("New highscore set: " + _scoreBoard.DisplayScore);
                _scoreBoard.HighScore = _scoreBoard.DisplayScore;
                _highscoreDate = DateTime.Now;

                // Save the new high score
                SaveGame();
            }
        }

        private void trex_JumpComplete(object sender, EventArgs e)
        {
            if (State == GameState.Transition)
            {
                // Change game state to "Playing" and reinitialize the T-Rex
                State = GameState.Playing;
                _trex.Initialize();

                // Enable the obstacle manager
                _obstacleManager.IsEnabled = true;
            }
        }
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Update
        //
        // Method parameters    :Update
        //
        // Method return        : 
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);

            KeyboardState keyboardState = Keyboard.GetState();

            if (State == GameState.Playing)
            {
                // Process player controls during gameplay
                _inputController.ProcessControls(gameTime);
            }
            else if (State == GameState.Transition)
            {
                // Update the fading-in animation
                _fadeInTexturePosX += (float)gameTime.ElapsedGameTime.TotalSeconds * FADE_IN_ANIMATION_SPEED;
            }
            else if (State == GameState.Initial)
            {
                // Check for the start key (Up or Space) to initiate the game
                bool isStartKeyPressed = keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.Space);
                bool wasStartKeyPressed = _previousKeyboardState.IsKeyDown(Keys.Up) || _previousKeyboardState.IsKeyDown(Keys.Space);

                if (isStartKeyPressed && !wasStartKeyPressed)
                {
                    // Start the game when the start key is pressed
                    StartGame();
                }
            }

            // Update game entities
            _entityManager.Update(gameTime);

            // Check for debug key presses
            if (keyboardState.IsKeyDown(Keys.F8) && !_previousKeyboardState.IsKeyDown(Keys.F8))
            {
                // Reset the game's save state
                ResetSaveState();
            }

            if (keyboardState.IsKeyDown(Keys.F12) && !_previousKeyboardState.IsKeyDown(Keys.F12))
            {
                // Toggle the display mode (e.g., full screen)
                ToggleDisplayMode();
            }

            // Store the current keyboard state for comparison
            _previousKeyboardState = keyboardState;
        }

        protected override void Draw(GameTime gameTime)
        {
            // Clear the graphics device
            if (_skyManager == null)
                GraphicsDevice.Clear(Color.White);
            else
                GraphicsDevice.Clear(_skyManager.ClearColor);

            _spriteBatch.Begin(samplerState: SamplerState.PointClamp, transformMatrix: _transformMatrix);

            // Draw game entities
            _entityManager.Draw(_spriteBatch, gameTime);

            if (State == GameState.Initial || State == GameState.Transition)
            {
                // Draw fading-in texture during initialization or transition
                _spriteBatch.Draw(_fadeInTexture, new Rectangle((int)Math.Round(_fadeInTexturePosX), 0, WINDOW_WIDTH, WINDOW_HEIGHT), Color.White);
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Start game / Replay / Load / Save / Reset Game
        //
        // Method parameters    : Start game / Replay / Load / Save / Reset Game
        //
        // Method return        : 
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        private bool StartGame()
        {
            // Start a new game if the current state is Initial
            if (State != GameState.Initial)
                return false;

            // Initialize the game state
            _scoreBoard.Score = 0;
            State = GameState.Transition;
            _trex.BeginJump();

            return true;
        }

        public bool Replay()
        {
            // Start a new game if the current state is GameOver
            if (State != GameState.GameOver)
                return false;

            // Reset the game state for a replay
            State = GameState.Playing;
            _trex.Initialize();

            // Reset and enable the obstacle manager
            _obstacleManager.Reset();
            _obstacleManager.IsEnabled = true;

            // Disable the game over screen and reset the score
            _gameOverScreen.IsEnabled = false;
            _scoreBoard.Score = 0;

            // Reinitialize the ground manager
            _groundManager.Initialize();

            // Block input temporarily during replay
            _inputController.BlockInputTemporarily();

            return true;
        }

        public void SaveGame()
        {
            // Create a SaveState object with highscore and date information
            SaveState saveState = new SaveState
            {
                Highscore = _scoreBoard.HighScore,
                HighscoreDate = _highscoreDate
            };

            try
            {
                // Serialize and save the SaveState object to a file
                using (FileStream fileStream = new FileStream(SAVE_FILE_NAME, FileMode.Create))
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    binaryFormatter.Serialize(fileStream, saveState);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("An error occurred while saving the game: " + ex.Message);
            }
        }

        public void LoadSaveState()
        {
            try
            {
                // Deserialize the SaveState object from a file
                using (FileStream fileStream = new FileStream(SAVE_FILE_NAME, FileMode.OpenOrCreate))
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    SaveState saveState = binaryFormatter.Deserialize(fileStream) as SaveState;

                    if (saveState != null)
                    {
                        // Update the highscore and highscore date if the SaveState is valid
                        if (_scoreBoard != null)
                            _scoreBoard.HighScore = saveState.Highscore;

                        _highscoreDate = saveState.HighscoreDate;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("An error occurred while loading the game: " + ex.Message);
            }
        }

        private void ResetSaveState()
        {
            // Reset the highscore and highscore date to default values and save the game
            _scoreBoard.HighScore = 0;
            _highscoreDate = default(DateTime);
            SaveGame();
        }
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        // Method                : Window 
        //
        // Method parameters    :Screen 
        //
        // Method return        : 
        //
        // Synopsis             :  
        //
        // Modifications        :
        //                            Date       Developer       Notes
        //                            22/11/23     Dhruvit          
        //
        //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        private void ToggleDisplayMode()
        {
            // Toggle between default and zoomed display modes
            if (WindowDisplayMode == DisplayMode.Default)
            {
                WindowDisplayMode = DisplayMode.Zoomed;
                _graphics.PreferredBackBufferHeight = WINDOW_HEIGHT * DISPLAY_ZOOM_FACTOR;
                _graphics.PreferredBackBufferWidth = WINDOW_WIDTH * DISPLAY_ZOOM_FACTOR;
                _transformMatrix = Matrix.Identity * Matrix.CreateScale(DISPLAY_ZOOM_FACTOR, DISPLAY_ZOOM_FACTOR, 1);
            }
            else
            {
                WindowDisplayMode = DisplayMode.Default;
                _graphics.PreferredBackBufferHeight = WINDOW_HEIGHT;
                _graphics.PreferredBackBufferWidth = WINDOW_WIDTH;
                _transformMatrix = Matrix.Identity;
            }

            _graphics.ApplyChanges();
        }

    }
}
